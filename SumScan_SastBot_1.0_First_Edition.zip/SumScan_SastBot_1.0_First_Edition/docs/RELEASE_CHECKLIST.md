# GitHub Release Checklist

## Before publishing

- Confirm `__version__ = "1.0.0"`.
- Run `python -m unittest discover -s tests -v`.
- Run `python -m compileall -q main.py sumscan`.
- Test `run_windows.bat` on a clean Windows environment.
- Test `install_kali.sh` and `run_linux.sh` on Kali/Debian-based Linux.
- Open Engine Manager and verify optional engine detection.
- Test one local project and one authorized GitHub repository.
- Export HTML, PDF, SARIF, JSON and CSV.
- Verify Secure Fix only changes the local working copy after confirmation.
- Confirm `history/` contains no private scan data before publishing.
- Confirm no `.env`, token, credential, private repository or customer code is committed.

## Suggested GitHub release

Tag:

```text
v1.0.0
```

Title:

```text
SumScan SastBot 1.0 — First Edition
```

Suggested release summary:

> First public edition of SumScan SastBot, a local-first Application Security and
> DevSecOps desktop workbench with multi-engine SAST, GitHub repository workflows,
> secure remediation guidance, reporting, quality gates and Windows/Kali Linux support.

Attach the source/release ZIP and any separately tested platform executable packages.
