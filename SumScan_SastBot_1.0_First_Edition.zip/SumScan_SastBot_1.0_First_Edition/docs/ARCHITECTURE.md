# Architecture

## Overview

SumScan SastBot 1.0 is a local-first PySide6 desktop application organized into
four primary layers:

```text
UI / User Workflow
        ↓
Analysis Orchestration
        ↓
Analyzer Plugins + Rule Packs
        ↓
Findings / Quality Gate / Reports / Local History
```

## UI layer

`sumscan/ui/`

Responsible for:
- dashboard and project navigation;
- live scan progress;
- findings and source context;
- GitHub account/repository workflow;
- Engine Manager;
- Secure Fix Preview;
- reports and history;
- SUMI guidance, animation and voice.

Long-running analysis is moved off the main UI thread through `QThread`.

## Analysis orchestration

`sumscan/core/engine.py`

`AnalysisEngine`:
1. discovers configured analyzer plugins;
2. checks availability;
3. runs selected analyzers;
4. normalizes findings into the common `Finding` model;
5. merges analyzer metrics;
6. evaluates the quality gate.

## Built-in analyzers

- Built-in Pattern Engine
- Python AST Analyzer
- DevSecOps Project Analyzer

The built-in file scanner uses `ThreadPoolExecutor` for project-level concurrency.

## Optional analyzer integrations

- Semgrep
- Bandit
- Trivy
- Gitleaks
- Tree-sitter Language Pack

External engines are optional. SumScan remains usable when they are unavailable.

## Rule pack

`sumscan/core/rules.py`

The First Edition core rule pack includes security checks for Python,
JavaScript/TypeScript, PHP, Java, C#, Go, Ruby, C/C++ and Kotlin.

Rule output includes:
- stable rule ID;
- severity;
- language;
- source file and line;
- CWE/reference;
- description;
- impact;
- remediation.

## GitHub integration

`sumscan/integrations/github/`

GitHub access uses local Git and GitHub CLI authentication. Repository scanning uses a
temporary local clone. SumScan does not provide an application field for GitHub passwords
or Personal Access Tokens.

## Secure remediation

`sumscan/core/fix_engine.py`

The Secure Fix workflow only offers deterministic code transformations for a limited
set of rules. User approval is required before changing the local working copy.
Unsupported findings receive remediation guidance instead of an unsafe automatic rewrite.

## Reporting

`sumscan/core/reports.py`

Supported formats:
- Interactive HTML
- Executive PDF
- SARIF 2.1.0
- JSON
- CSV

## Local history

Completed analyses are stored beneath `history/` when that location is writable.
A user-home fallback is used when the application directory cannot be written.

## Platform support

### Windows
- `run_windows.bat`
- Windows speech fallback
- PyInstaller build script

### Kali / Debian-based Linux
- `install_kali.sh`
- `run_linux.sh`
- `espeak-ng` offline voice fallback
- optional desktop launcher installer
