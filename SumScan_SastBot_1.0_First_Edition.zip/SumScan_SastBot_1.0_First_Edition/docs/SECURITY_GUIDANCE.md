# Security Guidance

SumScan SastBot is a defensive source-code analysis tool. Its rules prioritize
security-relevant code patterns and configuration indicators that benefit developers,
AppSec teams and authorized security reviewers.

## Core review areas

- authentication and credential handling;
- authorization and privilege boundaries;
- session and cookie security;
- injection sinks and unsafe dynamic execution;
- cross-site scripting indicators;
- sensitive information and logging;
- hard-coded secrets;
- unsafe deserialization;
- TLS and cryptographic configuration;
- file/path/process execution risks;
- CI/CD and container security;
- dependency and secret-analysis integration.

## Financial / e-commerce / API profile

The dashboard includes a financial AppSec profile emphasizing:
- identity and authorization;
- payment/sensitive-data handling;
- session integrity;
- injection resistance;
- cryptography and transport;
- logging and audit safety;
- API trust boundaries.

## Interpretation

A static-analysis finding is a lead for review, not proof of exploitability.
Application-specific business logic often requires manual analysis and runtime context.

Secure Fix suggestions also require human validation. A syntactically valid change can
still alter application behavior.

## External terminology

SumScan references CWE identifiers and security-testing terminology for classification
and guidance. These external standards are not proprietary SumScan content.
