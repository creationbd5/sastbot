# Privacy Model

## Built-in analysis

Built-in SumScan source analysis runs on the local machine. A SumScan-operated cloud
database is not required for scanning, history or report generation.

## GitHub

GitHub workflows use local Git and GitHub CLI. The repository is cloned locally before
analysis. Scan access does not require SumScan to modify the remote repository.

## Source changes

Secure Fix actions modify only the local working copy after explicit confirmation.
SumScan does not automatically push fixes to GitHub.

## SUMI voice

Offline voice processing can use the operating system's local speech engine.
When Natural Neural Voice is enabled, text-to-speech can use an online third-party
service. SUMI guidance should avoid reading sensitive source-code snippets aloud.

## Optional analysis engines

Semgrep, Bandit, Trivy, Gitleaks and Tree-sitter are independently maintained tools.
Users should review their configuration, licenses and data-handling behavior before use.
