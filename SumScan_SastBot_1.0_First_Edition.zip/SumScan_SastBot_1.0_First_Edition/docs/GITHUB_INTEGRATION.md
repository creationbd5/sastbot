# GitHub Integration

SumScan SastBot uses local Git and GitHub CLI authentication.

## Privacy model

- SumScan does not ask the user to type a GitHub password or Personal Access Token into the application.
- Repository scanning uses a temporary local clone.
- Scanning does not require repository write access.
- Applying a Secure Fix changes only the local working copy.
- SumScan does not automatically push code or create a remote commit.

Private repository access depends on permissions already granted to the connected GitHub account.
