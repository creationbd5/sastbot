# Quick Start

## Windows

1. Download the release ZIP.
2. Extract it completely.
3. Open the extracted folder.
4. Double-click `run_windows.bat`.
5. The launcher checks Python and installs required Python packages if needed.
6. Select **New Scan**, choose an authorized source-code project and start analysis.

If startup fails, run `diagnose_windows.bat` and review `startup_error.log`.

## Kali Linux / Debian-based Linux

```bash
chmod +x install_kali.sh run_linux.sh
./install_kali.sh
./run_linux.sh
```

The Linux build uses the same PySide6 desktop interface.

## Recommended optional engines

Open **Engine Manager** inside SumScan SastBot.

Recommended order:
1. Semgrep
2. Bandit
3. Tree-sitter Language Pack
4. Trivy
5. Gitleaks

System-level tools may require installation through the operating system or the
vendor's official package instructions.

## GitHub repositories

Open **GitHub** and connect using the GitHub CLI browser/device login workflow.
SumScan does not provide a password or PAT text field. Select an accessible repository,
clone it to a temporary local folder and start analysis.

## Secure Fix workflow

1. Select a finding.
2. Choose **Secure Fix Preview**.
3. Review the proposed before/after diff.
4. Edit the suggestion if necessary.
5. Confirm before modifying the local working copy.
6. Re-scan to verify the result.

SumScan does not automatically push a fix to GitHub.
