# Engine Manager

SumScan includes built-in analyzers and can use optional external engines.

| Engine | Purpose |
|---|---|
| Semgrep | Multi-language SAST and rules |
| Bandit | Python security analysis |
| Trivy | Dependency/SCA, filesystem and configuration scanning |
| Gitleaks | Secret detection |
| Tree-sitter | Multi-language structural parsing |

The application remains usable if optional engines are unavailable.

External engine findings are normalized into the SumScan findings/reporting workflow where supported.
