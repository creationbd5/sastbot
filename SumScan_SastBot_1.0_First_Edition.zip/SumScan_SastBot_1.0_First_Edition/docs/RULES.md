# Core Rule Pack

Rule pack version: **1.0.0**  
Built-in rules: **42**

| Rule ID | Severity | Language | Finding | Reference |
|---|---|---|---|---|
| `GEN-SEC-001` | Critical | All | Hardcoded Secret | CWE-798 |
| `GEN-URL-001` | Medium | All | Insecure HTTP Endpoint | CWE-319 |
| `PY-EVAL-001` | High | Python | Unsafe eval() | CWE-95 |
| `PY-EXEC-001` | High | Python | Unsafe exec() | CWE-95 |
| `PY-CRYPTO-001` | Medium | Python | Weak Hash Algorithm | CWE-327 |
| `PY-DBG-001` | Medium | Python | Debug Mode Enabled | CWE-489 |
| `PY-RAND-001` | Low | Python | Weak Random Generator | CWE-338 |
| `PY-SHELL-001` | High | Python | Shell Execution Enabled | CWE-78 |
| `PY-YAML-001` | High | Python | Unsafe YAML Load | CWE-502 |
| `PY-PICKLE-001` | High | Python | Pickle Deserialization | CWE-502 |
| `PY-SQL-001` | High | Python | Potential SQL Injection | CWE-89 |
| `PHP-EVAL-001` | High | PHP | Unsafe eval() | CWE-95 |
| `PHP-CMD-001` | High | PHP | OS Command Execution | CWE-78 |
| `PHP-SQL-001` | High | PHP | Potential SQL Injection | CWE-89 |
| `PHP-INCLUDE-001` | High | PHP | Dynamic File Include | CWE-98 |
| `JS-EVAL-001` | High | JavaScript | Unsafe eval() | CWE-95 |
| `JS-DOM-001` | Medium | JavaScript | Potential DOM XSS Sink | CWE-79 |
| `JS-TLS-001` | Critical | JavaScript | TLS Verification Disabled | CWE-295 |
| `GEN-LOG-001` | High | All | Potential Sensitive Data Logging | CWE-532 |
| `GEN-CORS-001` | High | All | Permissive CORS Configuration | CWE-942 |
| `GEN-JWT-001` | Critical | All | JWT Verification Disabled | CWE-347 |
| `GEN-CARD-001` | High | All | Hardcoded Payment Card-like Value | CWE-798 |
| `GEN-COOKIE-001` | Medium | All | Potential Insecure Cookie Configuration | CWE-614 |
| `JAVA-CMD-001` | High | Java | OS Command Execution | CWE-78 |
| `JAVA-DESER-001` | High | Java | Java Native Deserialization | CWE-502 |
| `CS-DESER-001` | Critical | C# | BinaryFormatter Deserialization | CWE-502 |
| `CS-TLS-001` | Critical | C# | TLS Certificate Validation Bypass | CWE-295 |
| `GO-TLS-001` | Critical | Go | TLS Verification Disabled | CWE-295 |
| `RB-EVAL-001` | High | Ruby | Unsafe eval() | CWE-95 |
| `RB-CMD-001` | High | Ruby | OS Command Execution | CWE-78 |
| `CPP-UNSAFE-001` | Medium | C/C++ | Potential Unsafe Memory Function | CWE-120 |
| `CPP-CMD-001` | High | C/C++ | OS Command Execution | CWE-78 |
| `KT-CMD-001` | High | Kotlin | OS Command Execution | CWE-78 |
| `GEN-TODO-SEC-001` | Low | All | Security TODO / FIXME | CWE-1059 |
| `PY-TLS-001` | Critical | Python | TLS Verification Disabled | CWE-295 |
| `PY-TEMP-001` | Medium | Python | Insecure Temporary File API | CWE-377 |
| `JS-CMD-001` | High | JavaScript | OS Command Execution | CWE-78 |
| `JS-REACT-XSS-001` | High | JavaScript | React Raw HTML Injection | CWE-79 |
| `JAVA-SQL-001` | High | Java | Potential SQL Injection | CWE-89 |
| `CS-CMD-001` | High | C# | OS Process Execution | CWE-78 |
| `GO-CMD-001` | High | Go | OS Command Execution | CWE-78 |
| `PHP-RAW-001` | Medium | PHP | Raw Database Expression | CWE-89 |

The built-in rule pack is intentionally conservative and is supplemented by optional external analyzers.
Automated results require manual validation.
