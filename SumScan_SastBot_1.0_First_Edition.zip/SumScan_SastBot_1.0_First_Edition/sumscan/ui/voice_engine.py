# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
# =============================================================================

import asyncio
import os
import platform
import subprocess
import tempfile
import threading
from pathlib import Path

from PySide6.QtCore import QObject, Signal, QUrl
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer

class VoiceEngine(QObject):
    speaking_changed = Signal(bool)
    message = Signal(str)
    neural_ready = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.enabled = True
        self.prefer_neural = True
        self.neural_voice = 'en-US-JennyNeural'
        self._busy = False
        self._lock = threading.Lock()
        self._temp_files = []

        self.audio = QAudioOutput(self)
        self.audio.setVolume(0.78)
        self.player = QMediaPlayer(self)
        self.player.setAudioOutput(self.audio)
        self.player.playbackStateChanged.connect(self._playback_changed)
        self.player.errorOccurred.connect(self._media_error)
        self.neural_ready.connect(self._play_file)

    def set_enabled(self, enabled):
        self.enabled = bool(enabled)
        if not self.enabled:
            self.player.stop()
            self.message.emit("Voice muted")

    def set_neural(self, enabled):
        self.prefer_neural = bool(enabled)

    def set_voice(self, voice_name):
        voices = {
            "Ava • Natural": "en-US-AvaNeural",
            "Jenny • Friendly": "en-US-JennyNeural",
            "Aria • Warm": "en-US-AriaNeural",
            "Sonia • British": "en-GB-SoniaNeural",
        }
        self.neural_voice = voices.get(voice_name, "en-US-AvaNeural")

    def _playback_changed(self, state):
        playing = state == QMediaPlayer.PlaybackState.PlayingState
        self.speaking_changed.emit(playing)
        if not playing and self._busy:
            self._busy = False

    def _media_error(self, *args):
        if self._busy:
            self._busy = False
            self.speaking_changed.emit(False)

    def _play_file(self, filename):
        path = Path(filename)
        if not path.exists():
            self._busy = False
            return
        self.player.setSource(QUrl.fromLocalFile(str(path)))
        self.player.play()

    def _edge_available(self):
        try:
            import edge_tts  # noqa: F401
            return True
        except Exception:
            return False

    def speak(self, text):
        if not self.enabled or not text.strip() or self._busy:
            return

        if self.prefer_neural and self._edge_available():
            self._speak_neural(text)
        else:
            import platform
            if platform.system().lower()=="windows":
                self._speak_windows(text)
            else:
                self._speak_linux(text)

    def test_voice(self):
        try:
            self.player.stop()
        except Exception:
            pass
        self._busy = False
        self.speak("Hi, I am Sumi. This is my new voice. I am ready to help with your security analysis.")

    def _speak_neural(self, text):
        self._busy = True
        self.speaking_changed.emit(True)

        def worker():
            try:
                import edge_tts
                temp = Path(tempfile.gettempdir()) / f"sumscan_sumi_{os.getpid()}_{len(self._temp_files)}.mp3"
                self._temp_files.append(temp)

                async def generate():
                    # Friendly, natural Microsoft neural female voice.
                    communicate = edge_tts.Communicate(
                        text=text,
                        voice=self.neural_voice,
                        rate="+4%",
                        pitch="+8Hz",
                        volume="+0%"
                    )
                    await communicate.save(str(temp))

                asyncio.run(generate())
                self.neural_ready.emit(str(temp))
            except Exception:
                self._busy = False
                self.speaking_changed.emit(False)
                self.message.emit("Neural voice unavailable. Using offline Windows voice.")
                self._speak_windows(text, force=True) if platform.system().lower()=="windows" else self._speak_linux(text, force=True)

        threading.Thread(target=worker, daemon=True).start()

    def _speak_linux(self, text, force=False):
        import shutil, subprocess, threading
        if not force and self._busy:
            return
        engine = shutil.which("espeak-ng") or shutil.which("espeak")
        if not engine:
            self.message.emit("Offline Linux voice is unavailable. Install espeak-ng, or keep Natural neural voice enabled.")
            return
        self._busy = True
        self.speaking_changed.emit(True)
        def worker():
            try:
                subprocess.run([engine,"-s","165","-p","58",text],capture_output=True,text=True,timeout=120)
            finally:
                self._busy=False
                self.speaking_changed.emit(False)
        threading.Thread(target=worker,daemon=True).start()

    def _speak_windows(self, text, force=False):
        if not force and self._busy:
            return
        if platform.system().lower() != "windows":
            self.message.emit("Offline voice guidance is available on Windows.")
            return

        self._busy = True
        self.speaking_changed.emit(True)

        def worker():
            with self._lock:
                try:
                    env = os.environ.copy()
                    env["SUMSCAN_TTS_TEXT"] = text
                    ps = r"""
Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$voices = $s.GetInstalledVoices() | ForEach-Object { $_.VoiceInfo }
$female = $voices | Where-Object { $_.Gender -eq 'Female' } | Select-Object -First 1
if ($female) { $s.SelectVoice($female.Name) }
$s.Rate = 1
$s.Volume = 90
$s.Speak($env:SUMSCAN_TTS_TEXT)
$s.Dispose()
"""
                    subprocess.run(
                        ["powershell.exe","-NoProfile","-NonInteractive","-ExecutionPolicy","Bypass","-Command",ps],
                        env=env,
                        capture_output=True,
                        text=True,
                        timeout=120,
                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                    )
                except Exception:
                    self.message.emit("Offline voice encountered an error.")
                finally:
                    self._busy = False
                    self.speaking_changed.emit(False)

        threading.Thread(target=worker, daemon=True).start()

    def cleanup(self):
        try:
            self.player.stop()
        except Exception:
            pass
        for path in self._temp_files:
            try:
                Path(path).unlink(missing_ok=True)
            except Exception:
                pass
