from PySide6.QtCore import QTimer, Signal
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QFrame,QTableWidget,QTableWidgetItem,QHeaderView,QMessageBox
from sumscan.integrations.github.account import account_status, begin_web_login, logout, list_repositories

class GitHubAccountPage(QWidget):
    repository_selected=Signal(str,str)
    def __init__(self,voice=None,parent=None):
        super().__init__(parent); self.voice=voice; self.build(); QTimer.singleShot(0,self.refresh_status)

    def build(self):
        lay=QVBoxLayout(self); lay.setContentsMargins(28,24,28,24)
        title=QLabel("GitHub Account & Repositories"); title.setStyleSheet("font-size:25px;font-weight:800"); lay.addWidget(title)
        note=QLabel("Connect through GitHub CLI's browser/device authentication. SumScan does not ask you to type a GitHub password or PAT into this application.")
        note.setWordWrap(True); note.setObjectName("muted"); lay.addWidget(note)
        card=QFrame(); card.setObjectName("privacyPanel"); cl=QVBoxLayout(card)
        self.status=QLabel("Checking GitHub account…"); self.status.setStyleSheet("font-size:15px;font-weight:800"); cl.addWidget(self.status)
        row=QHBoxLayout()
        self.connect_btn=QPushButton("Connect GitHub Account"); self.connect_btn.setObjectName("primary"); self.connect_btn.clicked.connect(self.connect)
        refresh=QPushButton("Refresh Account"); refresh.clicked.connect(self.refresh_status)
        disconnect=QPushButton("Disconnect"); disconnect.clicked.connect(self.disconnect)
        row.addWidget(self.connect_btn); row.addWidget(refresh); row.addWidget(disconnect); row.addStretch(); cl.addLayout(row); lay.addWidget(card)
        self.table=QTableWidget(0,4); self.table.setHorizontalHeaderLabels(["Repository","Visibility","Default Branch","Action"])
        self.table.horizontalHeader().setSectionResizeMode(0,QHeaderView.Stretch); lay.addWidget(self.table,1)

    def connect(self):
        try:
            begin_web_login()
            self.status.setText("GitHub sign-in started. Complete it, then click Refresh Account.")
            if self.voice:self.voice.speak("I opened GitHub's secure sign in flow. Your GitHub password is not entered into SumScan. Complete sign in, then return and choose refresh account.")
        except Exception as exc: QMessageBox.warning(self,"GitHub Account",str(exc))

    def disconnect(self):
        if QMessageBox.question(self,"Disconnect GitHub","Disconnect the GitHub CLI account on this computer?")!=QMessageBox.Yes:return
        try: logout(); self.refresh_status()
        except Exception as exc: QMessageBox.warning(self,"GitHub Account",str(exc))

    def refresh_status(self):
        st=account_status()
        if st.connected:
            self.status.setText(f"● CONNECTED  {st.username or 'GitHub account'}"); self.status.setStyleSheet("font-size:15px;font-weight:800;color:#72F0C8")
            self.connect_btn.setEnabled(False); self.load_repositories()
            if self.voice:self.voice.speak("GitHub account connected. I can now show repositories that this account is allowed to access.")
        else:
            self.status.setText("○ NOT CONNECTED  •  "+(st.message.splitlines()[0] if st.message else "Connect GitHub"))
            self.status.setStyleSheet("font-size:15px;font-weight:800;color:#F5D86A"); self.connect_btn.setEnabled(True); self.table.setRowCount(0)

    def load_repositories(self):
        try: repos=list_repositories(100)
        except Exception as exc:
            self.table.setRowCount(0); QMessageBox.warning(self,"GitHub Repositories",str(exc)); return
        self.table.setRowCount(len(repos))
        for r,item in enumerate(repos):
            owner=item.get("nameWithOwner",""); branch=(item.get("defaultBranchRef") or {}).get("name","main"); vis=item.get("visibility","PRIVATE" if item.get("isPrivate") else "PUBLIC")
            self.table.setItem(r,0,QTableWidgetItem(owner)); self.table.setItem(r,1,QTableWidgetItem(vis)); self.table.setItem(r,2,QTableWidgetItem(branch))
            btn=QPushButton("Scan Repository"); btn.clicked.connect(lambda checked=False,o=owner,b=branch:self.repository_selected.emit(o,b)); self.table.setCellWidget(r,3,btn)
