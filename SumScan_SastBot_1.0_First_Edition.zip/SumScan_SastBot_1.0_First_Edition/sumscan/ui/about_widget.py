# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
# =============================================================================

from PySide6.QtCore import QTimer, Qt
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QGridLayout
from PySide6.QtSvgWidgets import QSvgWidget
from sumscan import __version__

class TypewriterLabel(QLabel):
    def __init__(self, text, parent=None):
        super().__init__(parent)
        self.full=text; self.index=0
        self.setWordWrap(True)
        self.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.timer=QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(16)

    def tick(self):
        if self.index <= len(self.full):
            self.setText(self.full[:self.index] + "▋")
            self.index += 1
        else:
            self.setText(self.full)
            self.timer.stop()

class AboutPanel(QWidget):
    def __init__(self, logo_path, parent=None):
        super().__init__(parent)
        layout=QVBoxLayout(self)
        layout.setContentsMargins(28,24,28,24)
        layout.setSpacing(14)

        hero=QFrame(); hero.setObjectName("panel")
        row=QHBoxLayout(hero); row.setContentsMargins(22,20,22,20)
        logo=QSvgWidget(str(logo_path)); logo.setFixedSize(150,150); row.addWidget(logo)

        copy=QVBoxLayout()
        title=QLabel("SumScan SastBot")
        title.setStyleSheet("font-size:31px;font-weight:800;color:#FFFFFF")
        subtitle=QLabel(f"FIRST EDITION • VERSION {__version__}")
        subtitle.setStyleSheet("color:#6FE7FF;font-size:12px;font-weight:800;letter-spacing:1px")
        mission=QLabel(
            "A local-first Application Security and DevSecOps workbench for developers, "
            "security engineers, application-security teams and authorized penetration testers."
        )
        mission.setWordWrap(True); mission.setObjectName("muted")
        copy.addWidget(title); copy.addWidget(subtitle); copy.addSpacing(6); copy.addWidget(mission)
        copy.addWidget(TypewriterLabel(
            "Secure code review • Multi-engine SAST • GitHub workflow • Secure remediation • "
            "Quality gates • Developer-ready reporting"
        ))
        row.addLayout(copy,1); layout.addWidget(hero)

        grid=QGridLayout()
        cards=[
            ("LOCAL-FIRST","Built-in source analysis and reports operate on your device. No SumScan cloud database is required."),
            ("DEFENSIVE BY DESIGN","Designed for authorized secure code review, remediation, software quality and AppSec workflows."),
            ("EXTENSIBLE ENGINES","Integrates built-in analysis with optional Semgrep, Bandit, Trivy, Gitleaks and Tree-sitter."),
            ("HUMAN VALIDATION","Automated findings and suggested fixes require reviewer validation before production changes."),
        ]
        for i,(heading,text) in enumerate(cards):
            card=QFrame(); card.setObjectName("card"); cl=QVBoxLayout(card)
            h=QLabel(heading); h.setStyleSheet("font-weight:800;color:#72F0C8")
            b=QLabel(text); b.setWordWrap(True); b.setObjectName("muted")
            cl.addWidget(h); cl.addWidget(b)
            grid.addWidget(card,i//2,i%2)
        layout.addLayout(grid)

        author=QFrame(); author.setObjectName("panel"); al=QVBoxLayout(author)
        al.addWidget(QLabel("<b>Developed by Md Sumon Mahmud</b>"))
        contact=QLabel(
            "GitHub: github.com/creationbd5   •   Email: connect.sumon.mahmud@gmail.com   •   "
            "Website: www.sumonmahmud.com"
        )
        contact.setTextInteractionFlags(Qt.TextSelectableByMouse); contact.setObjectName("muted")
        legal=QLabel(
            "Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved. "
            "See LICENSE.txt, SECURITY.md and THIRD_PARTY_NOTICES.md for usage, security and attribution details."
        )
        legal.setWordWrap(True); legal.setObjectName("muted")
        al.addWidget(contact); al.addWidget(legal); layout.addWidget(author)
        layout.addStretch()
