from PySide6.QtCore import Qt, Signal, QThread
from PySide6.QtWidgets import (
    QDialog,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QPushButton,QCheckBox,
    QFrame,QMessageBox,QProgressBar
)
from sumscan.integrations.github.secure_clone import clone_repository

class CloneWorker(QThread):
    completed=Signal(object)
    failed=Signal(str)
    def __init__(self,url,branch):
        super().__init__(); self.url=url; self.branch=branch
    def run(self):
        try:self.completed.emit(clone_repository(self.url,self.branch,True))
        except Exception as e:self.failed.emit(str(e))

class GitHubConnectDialog(QDialog):
    repository_ready=Signal(object)
    def __init__(self,parent=None,voice=None):
        super().__init__(parent)
        self.voice=voice
        self.setWindowTitle("Secure GitHub Connect • SumScan SastBot")
        self.setMinimumWidth(720)
        lay=QVBoxLayout(self)

        title=QLabel("Securely Connect to GitHub")
        title.setStyleSheet("font-size:22px;font-weight:850;color:#F5FAFF")
        lay.addWidget(title)
        sub=QLabel("Local-first repository analysis. SumScan does not ask for or store a GitHub Personal Access Token.")
        sub.setWordWrap(True); sub.setObjectName("muted"); lay.addWidget(sub)

        privacy=QFrame(); privacy.setObjectName("privacyPanel"); pl=QVBoxLayout(privacy)
        pl.addWidget(QLabel("🔒 PRIVACY CHECK"))
        self.privacy_text=QLabel(
            "✓ Repository is cloned to a temporary folder on this computer\n"
            "✓ Built-in SAST analysis runs locally\n"
            "✓ No SumScan cloud database is required\n"
            "✓ No source-code monitoring service is built into this workflow\n"
            "✓ Private repositories use your existing Git / GitHub CLI authentication\n"
            "✓ Temporary clone can be removed after the scan"
        )
        self.privacy_text.setWordWrap(True); pl.addWidget(self.privacy_text); lay.addWidget(privacy)

        row=QHBoxLayout(); row.addWidget(QLabel("Repository URL"))
        self.url=QLineEdit(); self.url.setPlaceholderText("https://github.com/owner/repository")
        row.addWidget(self.url,1); lay.addLayout(row)
        row=QHBoxLayout(); row.addWidget(QLabel("Branch"))
        self.branch=QLineEdit("main"); row.addWidget(self.branch,1); lay.addLayout(row)

        self.cleanup=QCheckBox("Delete temporary repository copy when SumScan closes")
        self.cleanup.setChecked(True); lay.addWidget(self.cleanup)
        self.confirm=QCheckBox("I authorize SumScan to clone and analyze this repository on this computer.")
        lay.addWidget(self.confirm)

        self.progress=QProgressBar(); self.progress.setRange(0,1); self.progress.setValue(0); lay.addWidget(self.progress)
        actions=QHBoxLayout(); actions.addStretch()
        cancel=QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        self.go=QPushButton("Clone & Analyze"); self.go.setObjectName("primary"); self.go.clicked.connect(self.start)
        actions.addWidget(cancel); actions.addWidget(self.go); lay.addLayout(actions)

    def showEvent(self,e):
        super().showEvent(e)
        if self.voice:
            self.voice.speak("GitHub secure connect is ready. Your repository will be analyzed locally. Review the privacy check, then confirm if you want me to continue.")

    def start(self):
        if not self.confirm.isChecked():
            QMessageBox.warning(self,"Authorization Required","Please confirm that you are authorized to analyze this repository.")
            return
        if not self.url.text().strip():
            QMessageBox.warning(self,"Repository Required","Enter a GitHub repository URL.")
            return
        self.go.setEnabled(False); self.progress.setRange(0,0)
        if self.voice:self.voice.speak("Thanks. I will clone the selected repository to a temporary local folder. I will not modify the remote repository.")
        self.worker=CloneWorker(self.url.text(),self.branch.text())
        self.worker.completed.connect(self.done_ok); self.worker.failed.connect(self.done_fail); self.worker.start()

    def done_ok(self,result):
        self.progress.setRange(0,1); self.progress.setValue(1)
        if self.voice:self.voice.speak("Repository clone complete. Would you like me to start the security scan? I will prepare it now.")
        self.repository_ready.emit((result,self.cleanup.isChecked()))
        self.accept()

    def done_fail(self,msg):
        self.progress.setRange(0,1); self.go.setEnabled(True)
        QMessageBox.critical(self,"GitHub Connection Failed",msg)
        if self.voice:self.voice.speak("I could not connect to that repository. Please review the repository address, branch, and your GitHub authentication.")
