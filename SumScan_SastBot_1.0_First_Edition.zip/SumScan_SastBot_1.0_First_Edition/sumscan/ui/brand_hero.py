# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
# =============================================================================

import math
import random
from PySide6.QtCore import QTimer, Qt, QRectF, QPointF
from PySide6.QtGui import QPainter, QColor, QPen, QLinearGradient, QRadialGradient
from PySide6.QtWidgets import QWidget

class BrandHero(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setMinimumHeight(178)
        self.phase=0
        random.seed(7)
        self.nodes=[(random.random(),random.random(),random.uniform(.6,1.5)) for _ in range(22)]
        self.timer=QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(50)

    def tick(self):
        self.phase=(self.phase+1)%10000
        self.update()

    def paintEvent(self,event):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        rect=QRectF(self.rect()).adjusted(1,1,-1,-1)

        grad=QLinearGradient(rect.topLeft(),rect.topRight())
        grad.setColorAt(0,QColor("#07152F"))
        grad.setColorAt(.46,QColor("#11235A"))
        grad.setColorAt(1,QColor("#1A124E"))
        p.setBrush(grad); p.setPen(QPen(QColor("#2D67AF"),1.2))
        p.drawRoundedRect(rect,16,16)

        # moving network points
        pts=[]
        for x,y,s in self.nodes:
            px=rect.left()+x*rect.width()
            py=rect.top()+((y*rect.height()+self.phase*.035*s)%rect.height())
            pts.append(QPointF(px,py))
        for i,a in enumerate(pts):
            for b in pts[i+1:i+4]:
                dx=a.x()-b.x(); dy=a.y()-b.y()
                if dx*dx+dy*dy<9000:
                    p.setPen(QPen(QColor(70,155,255,24),1)); p.drawLine(a,b)
            p.setBrush(QColor(79,214,255,90)); p.setPen(Qt.NoPen); p.drawEllipse(a,1.7,1.7)

        # animated shield/orbit visual on left
        cx=105; cy=89
        pulse=6+3*math.sin(self.phase/16)
        glow=QRadialGradient(cx,cy,65+pulse)
        glow.setColorAt(0,QColor(53,157,255,110)); glow.setColorAt(.6,QColor(110,82,255,40)); glow.setColorAt(1,QColor(10,15,50,0))
        p.setBrush(glow); p.setPen(Qt.NoPen); p.drawEllipse(QRectF(cx-65,cy-65,130,130))
        p.setPen(QPen(QColor("#62DFFF"),3))
        p.drawRoundedRect(QRectF(cx-34,cy-38,68,72),20,20)
        p.setPen(QPen(QColor("#9A78FF"),2))
        p.drawLine(cx-19,cy,cx-6,cy-13); p.drawLine(cx-6,cy-13,cx+1,cy)
        p.drawLine(cx+8,cy-13,cx+21,cy)

        # title
        p.setPen(QColor("#F5F9FF"))
        font=p.font(); font.setFamily("Segoe UI"); font.setPointSize(27); font.setBold(True); p.setFont(font)
        p.drawText(QRectF(190,38,650,44),Qt.AlignLeft|Qt.AlignVCenter,"SumScan SastBot")

        font.setPointSize(11); font.setBold(False); p.setFont(font); p.setPen(QColor("#9DB8DD"))
        p.drawText(QRectF(192,85,720,30),Qt.AlignLeft|Qt.AlignVCenter,
                   "Multi-engine Static Application Security Testing • Guided by SUMI")

        # Right-side privacy/trust panel
        right_x = max(650, self.width()-355)
        p.setBrush(QColor(7,29,47,225)); p.setPen(QPen(QColor("#52E5C3"),1.2))
        p.drawRoundedRect(QRectF(right_x,28,305,116),12,12)
        font.setPointSize(10); font.setBold(True); p.setFont(font); p.setPen(QColor("#72F0C8"))
        p.drawText(QRectF(right_x+14,35,277,24),Qt.AlignLeft|Qt.AlignVCenter,"🔒 PRIVATE • LOCAL-FIRST")
        font.setPointSize(8); font.setBold(False); p.setFont(font); p.setPen(QColor("#D6F8F1"))
        lines=[
            "Your code stays under your control",
            "✓ Local built-in analysis",
            "✓ No SumScan cloud database required",
            "✓ Repository write access not required",
        ]
        yy=62
        for line in lines:
            p.drawText(QRectF(right_x+14,yy,277,18),Qt.AlignLeft|Qt.AlignVCenter,line); yy+=19

        # feature chips
        chips=["AST Analysis","Multi-language","CWE Guidance","SARIF Reports"]
        x=192
        for chip in chips:
            w=105 if chip!="Multi-language" else 115
            p.setBrush(QColor(14,31,71,220)); p.setPen(QPen(QColor("#315B9B"),1))
            p.drawRoundedRect(QRectF(x,126,w,30),10,10)
            p.setPen(QColor("#BFE4FF")); font.setPointSize(9); font.setBold(True); p.setFont(font)
            p.drawText(QRectF(x,126,w,30),Qt.AlignCenter,chip)
            x+=w+10
