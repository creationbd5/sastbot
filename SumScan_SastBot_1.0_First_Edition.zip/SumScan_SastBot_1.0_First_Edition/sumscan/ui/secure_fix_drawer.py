import html
from PySide6.QtCore import Signal
from PySide6.QtWidgets import QFrame,QVBoxLayout,QHBoxLayout,QLabel,QTextBrowser,QPlainTextEdit,QPushButton

class SecureFixDrawer(QFrame):
    apply_requested=Signal(str); rescan_requested=Signal()
    def __init__(self,parent=None):
        super().__init__(parent); self.setObjectName("findingDrawer"); self.setFixedWidth(570); self.current=None
        lay=QVBoxLayout(self); top=QHBoxLayout()
        title=QLabel("SECURE FIX WORKSPACE • SUMI"); title.setStyleSheet("font-size:15px;font-weight:900;color:#72F0C8")
        close=QPushButton("×"); close.setFixedWidth(38); close.clicked.connect(self.hide)
        top.addWidget(title); top.addStretch(); top.addWidget(close); lay.addLayout(top)
        self.info=QTextBrowser(); self.info.setMaximumHeight(190); lay.addWidget(self.info)
        lay.addWidget(QLabel("Suggested secure code • editable before applying"))
        self.editor=QPlainTextEdit(); self.editor.setStyleSheet("font-family:Consolas,monospace"); lay.addWidget(self.editor,1)
        lay.addWidget(QLabel("Before / After Diff"))
        self.diff=QTextBrowser(); self.diff.setMaximumHeight(170); lay.addWidget(self.diff)
        row=QHBoxLayout(); self.apply=QPushButton("Apply to Local Working Copy"); self.apply.setObjectName("primary")
        self.apply.clicked.connect(lambda:self.apply_requested.emit(self.editor.toPlainText()))
        rescan=QPushButton("Re-scan Project"); rescan.clicked.connect(self.rescan_requested.emit)
        row.addWidget(self.apply); row.addWidget(rescan); lay.addLayout(row)

    def set_proposal(self,finding,proposal):
        self.current=(finding,proposal)
        self.info.setHtml(f"<h2>{html.escape(finding.title)}</h2><p><b>{html.escape(finding.severity)}</b> • {html.escape(finding.rule_id)} • {html.escape(finding.reference)}</p><p>{html.escape(proposal.explanation)}</p><p><b>Fix confidence:</b> {html.escape(proposal.confidence)} • <b>Manual review:</b> Required</p>")
        self.editor.setPlainText(proposal.after if proposal.supported else finding.snippet); self.editor.setReadOnly(not proposal.supported)
        if proposal.supported:
            self.diff.setHtml("<pre>"+html.escape(proposal.diff)+"</pre>"); self.apply.setEnabled(True)
        else:
            self.diff.setHtml("<p>No safe deterministic rewrite is available for this rule. Use the remediation guidance and edit manually.</p>"); self.apply.setEnabled(False)
        self.show(); self.raise_()
