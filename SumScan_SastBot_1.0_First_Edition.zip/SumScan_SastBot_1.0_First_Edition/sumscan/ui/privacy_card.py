from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtSvgWidgets import QSvgWidget
from PySide6.QtWidgets import QFrame,QHBoxLayout,QVBoxLayout,QLabel
from sumscan.assets import asset_path

class PrivacyCard(QFrame):
    def __init__(self,parent=None):
        super().__init__(parent); self.setObjectName("privacyPanel")
        lay=QHBoxLayout(self)
        shield=QSvgWidget(asset_path("privacy_shield.svg")); shield.setFixedSize(105,125); lay.addWidget(shield)
        text=QVBoxLayout()
        h=QLabel("PRIVATE • LOCAL-FIRST"); h.setStyleSheet("font-size:15px;font-weight:900;color:#72F0C8"); text.addWidget(h)
        b=QLabel(
            "Your code stays under your control\n"
            "✓ Local built-in source analysis\n"
            "✓ No SumScan cloud database required\n"
            "✓ Reports stored on your device\n"
            "✓ Least-privilege GitHub workflow\n"
            "✓ No repository write action during scan"
        ); b.setWordWrap(True); text.addWidget(b)
        note=QLabel("PRIVACY BY DESIGN"); note.setStyleSheet("font-weight:850;color:#7DE7FF"); text.addWidget(note)
        lay.addLayout(text,1)
