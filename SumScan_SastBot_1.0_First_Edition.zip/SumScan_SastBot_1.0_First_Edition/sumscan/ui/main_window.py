# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
#
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
#
# Intended for authorized defensive security, secure code review, software
# quality assurance, remediation, and Application Security (AppSec).
# See LICENSE.txt for full terms, limitations, and third-party notices.
# =============================================================================

from pathlib import Path
import csv
import html
import json
import re
import webbrowser

from PySide6.QtCore import Qt, QObject, Signal, QThread, QUrl, QTimer
from PySide6.QtGui import QColor, QDesktopServices
from PySide6.QtSvgWidgets import QSvgWidget
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QFrame, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
    QGridLayout, QStackedWidget, QFileDialog, QTableWidget, QTableWidgetItem,
    QHeaderView, QLineEdit, QTextBrowser, QTextEdit, QComboBox, QProgressBar,
    QMessageBox, QCheckBox
)

from sumscan.core.engine import AnalysisEngine
from sumscan.core.models import Finding
from sumscan.core.rules import RULES
from sumscan.core.storage import save_scan, load_history, load_session, session_report_path
from sumscan.core.reports import result_payload, export_json, export_csv, export_sarif, export_html, export_pdf
from sumscan.core.references import reference_url
from sumscan.ui.theme import THEME
from sumscan.ui.animated_bg import AnimatedBackdrop
from sumscan.ui.about_widget import AboutPanel
from sumscan.ui.voice_engine import VoiceEngine
from sumscan.ui.sumi_mascot import SumiMascot
from sumscan.ui.sumi_drawer import SumiDrawer
from sumscan.ui.brand_hero import BrandHero
from sumscan.ui.finding_drawer import FindingDrawer
from sumscan.ui.github_dialog import GitHubConnectDialog
from sumscan.ui.github_account_page import GitHubAccountPage
from sumscan.ui.engine_manager_page import EngineManagerPage
from sumscan.ui.secure_fix_drawer import SecureFixDrawer
from sumscan.core.fix_engine import propose_fix, apply_line_replacement
from sumscan.integrations.github.secure_clone import cleanup_clone
from sumscan.core.cicd import save_github_template, save_gitlab_template

ORDER = {"Critical":0,"High":1,"Medium":2,"Low":3}
ACCENT = {"Critical":"#ff5c7a","High":"#fb923c","Medium":"#facc15","Low":"#22c55e"}

class ScanWorker(QObject):
    progress = Signal(int, str)
    finished = Signal(object)
    failed = Signal(str)

    def __init__(self, target, enabled):
        super().__init__()
        self.target = target
        self.enabled = enabled

    def run(self):
        try:
            engine = AnalysisEngine()
            result = engine.analyze(
                self.target,
                self.enabled,
                lambda pct, msg: self.progress.emit(pct, msg)
            )
            self.finished.emit(result)
        except Exception as exc:
            self.failed.emit(str(exc))

class StatCard(QFrame):
    def __init__(self, title, accent):
        super().__init__()
        self.setObjectName("card")
        self.setMinimumHeight(105)
        layout = QVBoxLayout(self)
        row = QHBoxLayout()
        dot = QLabel("●")
        dot.setStyleSheet(f"color:{accent};font-size:17px")
        row.addWidget(dot)
        row.addWidget(QLabel(title))
        row.addStretch()
        layout.addLayout(row)
        self.value = QLabel("0")
        self.value.setObjectName("statValue")
        layout.addWidget(self.value)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SumScan SastBot 1.0 • Security Analysis Studio")
        self.resize(1580, 940)
        self.setMinimumSize(1200, 780)
        self.setStyleSheet(THEME)

        self.engine = AnalysisEngine()
        self.engine_checks = {}
        self.findings = []
        self.filtered = []
        self.metrics = {}
        self.gate = None
        self.current_target = ""
        self.current_session_id = None
        self.thread = None
        self.worker = None

        self.build()

    def asset(self, *parts):
        return Path(__file__).parents[1] / "assets" / Path(*parts)

    def icon_path(self, name):
        return self.asset("icons", f"{name}.svg")

    def build(self):
        root = QWidget()
        self.setCentralWidget(root)
        outer = QHBoxLayout(root)
        outer.setContentsMargins(0,0,0,0)
        outer.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(242)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(14,18,14,14)

        # Clean sidebar branding: SVG shield only.
        brand_row = QHBoxLayout()
        brand_row.setContentsMargins(0, 8, 0, 4)
        brand_row.addStretch()

        logo = QSvgWidget(str(self.asset("logo.svg")))
        logo.setFixedSize(118, 118)
        brand_row.addWidget(logo, 0, Qt.AlignCenter)

        brand_row.addStretch()
        side.addLayout(brand_row)
        side.addSpacing(14)

        nav_items = [
            ("Dashboard","dashboard",0),
            ("New Scan","scan",1),
            ("GitHub","engines",2),
            ("Findings","findings",3),
            ("Engines","engines",4),
            ("Engine Manager","engines",5),
            ("Rules","rules",6),
            ("DevSecOps","engines",7),
            ("Reports","reports",8),
            ("History","history",9),
            ("About","about",10),
        ]
        self.nav = []
        from PySide6.QtGui import QIcon
        for text, icon_name, idx in nav_items:
            button = QPushButton(text)
            button.setIcon(QIcon(str(self.icon_path(icon_name))))
            button.setObjectName("nav")
            button.setCheckable(True)
            button.clicked.connect(lambda checked=False, i=idx: self.set_page(i))
            side.addWidget(button)
            self.nav.append(button)

        # Quick SUMI voice controls are placed next to the assistant, not behind it.
        self.quick_voice = QComboBox()
        self.quick_voice.addItems(["Jenny • Friendly","Ava • Natural","Aria • Warm","Sonia • British"])
        self.quick_voice.setToolTip("SUMI voice")
        self.quick_voice.currentTextChanged.connect(lambda name: getattr(self, "voice_engine", None) and self.voice_engine.set_voice(name))
        side.addWidget(self.quick_voice)
        self.quick_voice_test = QPushButton("🔊 Test SUMI Voice")
        self.quick_voice_test.clicked.connect(lambda: getattr(self, "voice_engine", None) and self.voice_engine.test_voice())
        side.addWidget(self.quick_voice_test)
        side.addStretch()
        outer.addWidget(sidebar)

        host = QWidget()
        host_layout = QVBoxLayout(host)
        host_layout.setContentsMargins(0,0,0,0)
        self.backdrop = AnimatedBackdrop(host)
        self.backdrop.lower()
        self.pages = QStackedWidget()
        self.pages.setStyleSheet("background:transparent")
        host_layout.addWidget(self.pages, 1)

        self.live_bar = QFrame()
        self.live_bar.setObjectName("liveBar")
        lb = QHBoxLayout(self.live_bar)
        lb.setContentsMargins(12,4,12,4)
        self.live_engine = QLabel("● ENGINE READY")
        self.live_engine.setStyleSheet("color:#72F0C8;font-weight:800")
        self.live_file = QLabel("No active scan")
        self.live_file.setObjectName("muted")
        self.live_progress = QProgressBar()
        self.live_progress.setRange(0,100)
        self.live_progress.setValue(0)
        self.live_progress.setMaximumWidth(260)
        self.live_project = QLabel("Project: —")
        self.live_project.setObjectName("muted")
        self.live_version = QLabel("SumScan SastBot 1.0")
        self.live_version.setStyleSheet("color:#7DE7FF;font-weight:700")
        lb.addWidget(self.live_engine)
        lb.addWidget(self.live_file,1)
        lb.addWidget(self.live_progress)
        lb.addWidget(self.live_project)
        lb.addWidget(self.live_version)
        host_layout.addWidget(self.live_bar)

        outer.addWidget(host, 1)

        self.pages.addWidget(self.dashboard_page())
        self.pages.addWidget(self.scan_page())
        self.github_page = GitHubAccountPage(None)
        self.github_page.repository_selected.connect(self.scan_connected_repository)
        self.pages.addWidget(self.github_page)
        self.pages.addWidget(self.findings_page())
        self.pages.addWidget(self.engines_page())
        self.engine_manager_page_widget = EngineManagerPage(None)
        self.pages.addWidget(self.engine_manager_page_widget)
        self.pages.addWidget(self.rules_page())
        self.pages.addWidget(self.devsecops_page())
        self.pages.addWidget(self.reports_page())
        self.pages.addWidget(self.history_page())
        self.pages.addWidget(self.about_page())

        self.set_page(0)
        self.refresh_history()

        # SUMI animated local voice guide
        self.voice_engine = VoiceEngine(self)
        if hasattr(self, "github_page"): self.github_page.voice = self.voice_engine
        if hasattr(self, "engine_manager_page_widget"): self.engine_manager_page_widget.voice = self.voice_engine
        self.voice_engine.speaking_changed.connect(self.on_sumi_speaking)
        self.voice_engine.message.connect(self.on_sumi_message)

        self.sumi_mascot = SumiMascot(self)
        self.sumi_mascot.clicked.connect(self.toggle_sumi_drawer)

        self.sumi_drawer = SumiDrawer(self)
        self.sumi_drawer.action_requested.connect(self.sumi_action)
        self.sumi_drawer.mute_changed.connect(lambda muted: self.voice_engine.set_enabled(not muted))
        self.sumi_drawer.neural_box.toggled.connect(self.voice_engine.set_neural)
        self.sumi_drawer.voice_selector.currentTextChanged.connect(self.voice_engine.set_voice)
        self.sumi_drawer.test_voice_requested.connect(self.voice_engine.test_voice)
        self.sumi_drawer.hide()
        self.position_sumi()

        self.finding_drawer = FindingDrawer(self)
        self.finding_drawer.hide()
        self.position_finding_drawer()
        self.secure_fix_drawer = SecureFixDrawer(self)
        self.secure_fix_drawer.apply_requested.connect(self.apply_secure_fix)
        self.secure_fix_drawer.rescan_requested.connect(self.rescan_after_fix)
        self.secure_fix_drawer.hide()
        self.position_secure_fix_drawer()

        # Gentle welcome, once per launch.
        self.voice_engine.speak(
            "Hi. I am Sumi, your SumScan security guide. "
            "Choose a project when you are ready to begin."
        )

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "backdrop"):
            self.backdrop.setGeometry(self.centralWidget().rect())
        if hasattr(self, "sumi_mascot"):
            self.position_sumi()
        if hasattr(self, "finding_drawer"):
            self.position_finding_drawer()
        if hasattr(self, "secure_fix_drawer"): self.position_secure_fix_drawer()

    def position_sumi(self):
        # SUMI lives on the left, visually connected to the main product branding.
        margin = 14
        sidebar_width = 242
        self.sumi_mascot.move(
            25,
            self.height() - self.sumi_mascot.height() - 28
        )
        self.sumi_mascot.raise_()

        drawer_h = min(520, max(360, self.height() - 180))
        self.sumi_drawer.setGeometry(
            sidebar_width + margin,
            max(76, self.height() - drawer_h - 100),
            self.sumi_drawer.width(),
            drawer_h
        )
        self.sumi_drawer.raise_()

    def position_finding_drawer(self):
        h=max(420,self.height()-150)
        self.finding_drawer.setGeometry(
            self.width()-self.finding_drawer.width()-18,
            78,
            self.finding_drawer.width(),
            min(h,self.height()-105)
        )

    def open_finding_drawer(self):
        rows=self.findings_table.selectionModel().selectedRows()
        if not rows or not getattr(self,"filtered",[]): return
        f=self.filtered[rows[0].row()]
        self.finding_drawer.show_finding(f,self.infer_engine(f),reference_url(f.reference))
        self.position_finding_drawer()

    def position_secure_fix_drawer(self):
        h=max(440,self.height()-150)
        self.secure_fix_drawer.setGeometry(self.width()-self.secure_fix_drawer.width()-18,78,self.secure_fix_drawer.width(),min(h,self.height()-105))

    def scan_connected_repository(self,owner_repo,branch):
        dlg=GitHubConnectDialog(self,self.voice_engine)
        dlg.url.setText(f"https://github.com/{owner_repo}"); dlg.branch.setText(branch or "main"); dlg.confirm.setChecked(True)
        dlg.repository_ready.connect(self.github_repository_ready)
        self.voice_engine.speak(f"You selected {owner_repo}. I prepared the secure local clone workflow. Review it and confirm if you want me to continue.")
        dlg.exec()

    def toggle_sumi_drawer(self):
        self.sumi_drawer.setVisible(not self.sumi_drawer.isVisible())
        self.position_sumi()

    def on_sumi_speaking(self, speaking):
        self.sumi_mascot.set_talking(speaking)
        if speaking:
            self.sumi_drawer.state.setText("● TALKING")
            self.sumi_drawer.state.setStyleSheet("color:#62E6FF;font-weight:800")
        else:
            self.sumi_drawer.state.setText("● READY")
            self.sumi_drawer.state.setStyleSheet("color:#72F0C8;font-weight:800")

    def on_sumi_message(self, message):
        self.sumi_drawer.say("SUMI Voice", message, "INFO")

    def sumi_action(self, action):
        if action == "guide":
            self.set_page(1)
            body = (
                "First, click Browse Project and choose code you are authorized to review. "
                "Keep the built-in analyzers enabled, then click Start Analysis. "
                "I will tell you when the scan finishes."
            )
            self.sumi_drawer.say("First Scan Guide", body, "GUIDING")
            self.voice_engine.speak(
                "First, choose a source code project you are authorized to review. "
                "Then start the analysis. I will guide you through the results."
            )
        elif action == "explain":
            rows = self.findings_table.selectionModel().selectedRows()
            if not rows or not getattr(self, "filtered", []):
                self.sumi_drawer.say("Select a Finding", "Choose a finding from the Findings table first.", "WAITING")
                self.voice_engine.speak("Please select a finding first.")
                return
            finding = self.filtered[rows[0].row()]
            body = (
                f"<b>{finding.severity}</b> • {finding.reference}<br>"
                f"{finding.description}<br><br>"
                f"<b>Recommendation:</b> {finding.recommendation}<br><br>"
                "Manual validation is recommended."
            )
            self.sumi_mascot.set_thinking()
            self.sumi_drawer.say(finding.title, body, "EXPLAINING")
            spoken = (
                f"{finding.title}. Severity {finding.severity}. "
                f"{finding.description} "
                f"Recommendation. {finding.recommendation} "
                "Please validate this finding before making production decisions."
            )
            self.voice_engine.speak(spoken)
        elif action == "critical":
            critical = [f for f in self.findings if f.severity == "Critical"]
            self.set_page(3)
            try:
                self.severity_filter.setCurrentText("Critical")
            except Exception:
                pass
            self.sumi_mascot.set_alert(bool(critical))
            body = f"I found <b>{len(critical)}</b> critical finding(s) in the active analysis."
            self.sumi_drawer.say("Critical Review", body, "ALERT" if critical else "CLEAR")
            if critical:
                self.voice_engine.speak(
                    f"I found {len(critical)} critical findings. "
                    "Please review the highlighted source context and remediation guidance."
                )
            else:
                self.voice_engine.speak("No critical findings are currently listed.")
        elif action == "reports":
            self.set_page(8)
            self.sumi_drawer.say(
                "Reports",
                "Use Interactive HTML for review, SARIF for compatible CI workflows, "
                "or JSON and CSV for downstream processing.",
                "READY"
            )
            self.voice_engine.speak(
                "The reports page is open. You can export HTML, SARIF, JSON, or CSV."
            )

    def set_page(self, index):
        self.pages.setCurrentIndex(index)
        for i, button in enumerate(self.nav):
            button.setChecked(i == index)

    def header(self, title, subtitle):
        box = QVBoxLayout()
        title_label = QLabel(title)
        title_label.setObjectName("pageTitle")
        subtitle_label = QLabel(subtitle)
        subtitle_label.setObjectName("muted")
        box.addWidget(title_label)
        box.addWidget(subtitle_label)
        return box

    # ---------------- Dashboard ----------------
    def dashboard_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28,24,28,24)
        layout.setSpacing(14)
        layout.addLayout(self.header(
            "Application Security Dashboard",
            "Security findings, hotspots, quality gate and maintainability metrics"
        ))

        self.brand_hero = BrandHero()
        layout.addWidget(self.brand_hero)

        profile = QFrame()
        profile.setObjectName("panel")
        pr = QHBoxLayout(profile)
        badge = QLabel("FINANCIAL APPSEC PROFILE")
        badge.setStyleSheet("color:#7dd3fc;font-weight:800;letter-spacing:1px")
        desc = QLabel("Prioritizes identity, authorization, sessions, injection, sensitive data, cryptography, business logic and API trust boundaries.")
        desc.setObjectName("muted")
        desc.setWordWrap(True)
        pr.addWidget(badge)
        pr.addWidget(desc, 1)
        layout.addWidget(profile)

        self.quality_banner = QFrame()
        self.quality_banner.setObjectName("panel")
        qb = QHBoxLayout(self.quality_banner)
        self.quality_icon = QLabel("◆")
        self.quality_icon.setStyleSheet("font-size:26px;color:#64748b")
        self.quality_text = QLabel("<b>NO ANALYSIS</b><br><span style='color:#8ea3bd'>Run a project scan to calculate the quality gate.</span>")
        qb.addWidget(self.quality_icon)
        qb.addWidget(self.quality_text, 1)
        layout.addWidget(self.quality_banner)

        row = QHBoxLayout()
        self.cards = {}
        for severity in ["Critical","High","Medium","Low"]:
            card = StatCard(severity, ACCENT[severity])
            self.cards[severity] = card
            row.addWidget(card)
        total = StatCard("Vulnerabilities", "#38bdf8")
        self.cards["Total"] = total
        row.addWidget(total)
        layout.addLayout(row)

        metrics = QFrame()
        metrics.setObjectName("panel")
        grid = QGridLayout(metrics)
        self.score_value = QLabel("—")
        self.debt_value = QLabel("—")
        self.complexity_value = QLabel("—")
        self.coverage_value = QLabel("N/A")
        self.hotspot_value = QLabel("0")
        for value in [self.score_value,self.debt_value,self.complexity_value,self.coverage_value,self.hotspot_value]:
            value.setObjectName("statValue")
        items = [
            ("Security Score", self.score_value),
            ("Technical Debt", self.debt_value),
            ("Avg. Complexity", self.complexity_value),
            ("Code Coverage", self.coverage_value),
            ("Security Hotspots", self.hotspot_value),
        ]
        for col,(title,value) in enumerate(items):
            box = QVBoxLayout()
            label = QLabel(title)
            label.setObjectName("muted")
            box.addWidget(label)
            box.addWidget(value)
            grid.addLayout(box,0,col)
        layout.addWidget(metrics)

        quick = QHBoxLayout()
        local_cta = QPushButton("New Local Scan")
        local_cta.clicked.connect(lambda:self.set_page(1))
        github_scan_cta = QPushButton("GitHub Scan")
        github_scan_cta.setObjectName("primary")
        github_scan_cta.clicked.connect(self.open_github_connect)
        quick.addWidget(local_cta)
        quick.addWidget(github_scan_cta)
        quick.addStretch()
        layout.addLayout(quick)

        self.target_label = QLabel("No active project")
        self.target_label.setObjectName("muted")
        layout.addWidget(self.target_label)

        self.dash_history = QTableWidget(0,5)
        self.dash_history.setHorizontalHeaderLabels(["Project","Files","Findings","Gate","Date"])
        self.dash_history.horizontalHeader().setSectionResizeMode(0,QHeaderView.Stretch)
        self.dash_history.setEditTriggers(QTableWidget.NoEditTriggers)
        self.dash_history.setSelectionBehavior(QTableWidget.SelectRows)
        self.dash_history.doubleClicked.connect(self.load_history_from_dashboard)
        layout.addWidget(self.dash_history,1)
        return page

    def open_github_connect(self):
        dlg = GitHubConnectDialog(self, self.voice_engine)
        dlg.repository_ready.connect(self.github_repository_ready)
        dlg.exec()

    def github_repository_ready(self, payload):
        result, auto_cleanup = payload
        self.path_edit.setText(result.local_path)
        self.current_target = result.local_path
        if auto_cleanup:
            self.github_temp_clones.append(result.local_path)
        self.activity.append(
            f"GitHub repository ready: {result.repository} • branch {result.branch} • "
            f"commit {result.commit[:12]} • {result.transport}"
        )
        self.live_project.setText(f"GitHub: {result.repository}@{result.branch}")
        self.set_page(1)
        answer = QMessageBox.question(
            self,
            "SUMI • Start Security Analysis",
            f"Repository cloned locally.\n\n{result.repository}\nBranch: {result.branch}\n"
            f"Commit: {result.commit[:12]}\n\nStart the security scan now?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.Yes,
        )
        if answer == QMessageBox.Yes:
            self.voice_engine.speak(
                "Starting the local security analysis now. "
                "I will keep you updated as files are analyzed."
            )
            self.start_scan()
        else:
            self.voice_engine.speak(
                "No problem. The repository is ready. "
                "Start the scan whenever you are ready."
            )

    # ---------------- New Scan ----------------
    def scan_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28,24,28,24)
        layout.setSpacing(14)
        layout.addLayout(self.header(
            "New Scan",
            "Run built-in analyzers and optional external engines in a background worker"
        ))

        panel = QFrame()
        panel.setObjectName("panel")
        pl = QVBoxLayout(panel)

        target_row = QHBoxLayout()
        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("Select a source-code project directory")
        browse = QPushButton("Browse Project")
        browse.clicked.connect(self.choose_target)
        target_row.addWidget(self.path_edit,1)
        target_row.addWidget(browse)
        pl.addLayout(target_row)

        pl.addWidget(QLabel("Analyzer Plugins"))
        plugin_grid = QGridLayout()
        for idx, item in enumerate(self.engine.plugin_status()):
            cb = QCheckBox(item["name"])
            built_in = item["id"].startswith("builtin.")
            cb.setEnabled(item["available"] or built_in)
            cb.setChecked(item["available"] or built_in)
            cb.setToolTip(f'{item["category"]} • {item["note"]}')
            self.engine_checks[item["id"]] = cb
            plugin_grid.addWidget(cb,idx//3,idx%3)
        pl.addLayout(plugin_grid)

        run_row = QHBoxLayout()
        self.run_btn = QPushButton("Start Analysis")
        self.run_btn.setObjectName("primary")
        self.run_btn.clicked.connect(self.start_scan)
        self.progress = QProgressBar()
        self.progress.setValue(0)
        self.status = QLabel("Ready")
        self.status.setObjectName("muted")
        run_row.addWidget(self.run_btn)
        run_row.addWidget(self.progress,1)
        run_row.addWidget(self.status)
        pl.addLayout(run_row)
        layout.addWidget(panel)

        activity_panel = QFrame()
        activity_panel.setObjectName("panel")
        al = QVBoxLayout(activity_panel)
        al.addWidget(QLabel("Live Analysis Activity"))
        self.activity = QTextEdit()
        self.activity.setReadOnly(True)
        self.activity.setPlainText("SumScan engine ready.")
        al.addWidget(self.activity)
        layout.addWidget(activity_panel,1)
        return page

    # ---------------- Findings ----------------
    def findings_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28,24,28,24)
        layout.setSpacing(10)
        layout.addLayout(self.header(
            "Interactive Findings Viewer",
            "Filter issues and review highlighted source context, CWE links and remediation"
        ))

        filters = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search rule, file, title, code...")
        self.search.textChanged.connect(self.apply_filters)

        self.severity_filter = QComboBox()
        self.severity_filter.addItems(["All severities","Critical","High","Medium","Low"])
        self.severity_filter.currentTextChanged.connect(self.apply_filters)

        self.engine_filter = QComboBox()
        self.engine_filter.addItems(["All engines","Built-in","AST","Semgrep","Bandit","Trivy","Gitleaks"])
        self.engine_filter.currentTextChanged.connect(self.apply_filters)

        self.extension_filter = QComboBox()
        self.extension_filter.addItem("All extensions")
        self.extension_filter.currentTextChanged.connect(self.apply_filters)

        self.status_filter = QComboBox()
        self.status_filter.addItems(["Open","All statuses","False Positive","Resolved"])
        self.status_filter.currentTextChanged.connect(self.apply_filters)

        filters.addWidget(self.search,1)
        filters.addWidget(self.severity_filter)
        filters.addWidget(self.engine_filter)
        filters.addWidget(self.extension_filter)
        filters.addWidget(self.status_filter)
        layout.addLayout(filters)

        body = QHBoxLayout()
        self.findings_table = QTableWidget(0,7)
        self.findings_table.setHorizontalHeaderLabels(["Severity","Engine","Language","Finding","File","Line","Rule"])
        self.findings_table.horizontalHeader().setSectionResizeMode(3,QHeaderView.Stretch)
        self.findings_table.horizontalHeader().setSectionResizeMode(4,QHeaderView.Stretch)
        self.findings_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.findings_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.findings_table.itemSelectionChanged.connect(self.render_selected)
        self.findings_table.doubleClicked.connect(self.open_finding_drawer)
        body.addWidget(self.findings_table,3)

        right = QFrame()
        right.setObjectName("panel")
        right_layout = QVBoxLayout(right)

        self.detail = QTextBrowser()
        self.detail.setOpenExternalLinks(True)
        right_layout.addWidget(self.detail,2)

        code_label = QLabel("Source Code")
        code_label.setStyleSheet("font-weight:600")
        right_layout.addWidget(code_label)

        self.source_view = QTextBrowser()
        self.source_view.setOpenExternalLinks(False)
        right_layout.addWidget(self.source_view,3)

        self.fix_view = QTextBrowser()
        self.fix_view.setMaximumHeight(125)
        right_layout.addWidget(self.fix_view)
        fix_actions = QHBoxLayout()
        secure_fix_btn = QPushButton("✨ Secure Fix Preview")
        secure_fix_btn.setObjectName("primary")
        secure_fix_btn.clicked.connect(self.open_secure_fix)
        ask_sumi_btn = QPushButton("Ask SUMI")
        ask_sumi_btn.clicked.connect(lambda:self.sumi_action("explain"))
        fix_actions.addWidget(secure_fix_btn); fix_actions.addWidget(ask_sumi_btn)
        right_layout.addLayout(fix_actions)

        body.addWidget(right,2)
        layout.addLayout(body,1)
        return page

    # ---------------- Engines ----------------
    def engines_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28,24,28,24)
        layout.addLayout(self.header(
            "Analysis Engines",
            "Installed engines are detected at runtime; SumScan remains usable with built-in analyzers"
        ))

        grid = QGridLayout()
        for idx,item in enumerate(self.engine.plugin_status()):
            card = QFrame()
            card.setObjectName("card")
            c = QVBoxLayout(card)
            state = "● AVAILABLE" if item["available"] else "○ OPTIONAL"
            state_color = "#22c55e" if item["available"] else "#64748b"
            s = QLabel(state)
            s.setStyleSheet(f"color:{state_color};font-weight:700")
            c.addWidget(s)
            title = QLabel(item["name"])
            title.setStyleSheet("font-size:17px;font-weight:650")
            c.addWidget(title)
            meta = QLabel(f'{item["category"]}<br>{item["note"]}')
            meta.setObjectName("muted")
            meta.setWordWrap(True)
            c.addWidget(meta)
            grid.addWidget(card,idx//2,idx%2)
        layout.addLayout(grid)
        layout.addStretch()
        return page

    # ---------------- Rules ----------------
    def rules_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28,24,28,24)
        layout.addLayout(self.header(
            "Rule Catalog",
            f"{len(RULES)} built-in pattern rules plus AST and external engine rule packs"
        ))
        table = QTableWidget(len(RULES),5)
        table.setHorizontalHeaderLabels(["Rule ID","Language","Severity","Title","Reference"])
        table.horizontalHeader().setSectionResizeMode(3,QHeaderView.Stretch)
        table.horizontalHeader().setSectionResizeMode(4,QHeaderView.Stretch)
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        for r,rule in enumerate(RULES):
            for c,value in enumerate([rule.rule_id,rule.language,rule.severity,rule.title,rule.reference]):
                table.setItem(r,c,QTableWidgetItem(str(value)))
        layout.addWidget(table)
        return page

    # ---------------- DevSecOps ----------------
    def devsecops_page(self):
        page=QWidget()
        layout=QVBoxLayout(page)
        layout.setContentsMargins(28,24,28,24)
        layout.addLayout(self.header(
            "DevSecOps & Developer Workspace",
            "Project inventory, CI/CD readiness, language coverage and secure delivery helpers"
        ))

        top=QHBoxLayout()
        self.dev_lang=QTextBrowser()
        self.dev_lang.setMinimumHeight(170)
        self.dev_manifest=QTextBrowser()
        self.dev_manifest.setMinimumHeight(170)
        top.addWidget(self.dev_lang,1); top.addWidget(self.dev_manifest,1)
        layout.addLayout(top)

        engine_box=QFrame(); engine_box.setObjectName("panel")
        el=QVBoxLayout(engine_box)
        el.addWidget(QLabel("Security Toolchain"))
        self.dev_engines=QTextBrowser(); self.dev_engines.setMaximumHeight(170)
        statuses=self.engine.plugin_status()
        engine_html="<table width='100%'>"
        for s in statuses:
            mark="●" if s["available"] else "○"
            color="#72F0C8" if s["available"] else "#8FA9D5"
            engine_html+=f"<tr><td style='color:{color}'>{mark}</td><td><b>{html.escape(s['name'])}</b></td><td>{html.escape(s['category'])}</td><td>{html.escape(s['note'])}</td></tr>"
        engine_html+="</table>"
        self.dev_engines.setHtml(engine_html)
        el.addWidget(self.dev_engines)
        layout.addWidget(engine_box)

        actions=QHBoxLayout()
        refresh=QPushButton("Refresh Project Inventory")
        refresh.clicked.connect(self.refresh_devsecops)
        gh=QPushButton("Generate GitHub Actions Template")
        gh.clicked.connect(lambda:self.generate_ci_template("github"))
        gl=QPushButton("Generate GitLab CI Template")
        gl.clicked.connect(lambda:self.generate_ci_template("gitlab"))
        reports_btn=QPushButton("Open Reports")
        reports_btn.clicked.connect(lambda:self.set_page(8))
        actions.addWidget(refresh); actions.addWidget(gh); actions.addWidget(gl); actions.addWidget(reports_btn); actions.addStretch()
        layout.addLayout(actions)
        layout.addStretch()
        QTimer.singleShot(0,self.refresh_devsecops)
        return page

    def refresh_devsecops(self):
        languages=self.metrics.get("language_inventory",{}) if self.metrics else {}
        manifests=self.metrics.get("manifests",[]) if self.metrics else []
        ci=self.metrics.get("ci_files",[]) if self.metrics else []
        containers=self.metrics.get("container_files",[]) if self.metrics else []
        if languages:
            rows="".join(f"<tr><td><b>{html.escape(str(k))}</b></td><td>{v} files</td></tr>" for k,v in languages.items())
            self.dev_lang.setHtml("<h3>Language Inventory</h3><table>"+rows+"</table>")
        else:
            self.dev_lang.setHtml("<h3>Language Inventory</h3><p>Run a scan to build the project inventory.</p>")
        parts=["<h3>Build & Delivery Files</h3>"]
        parts.append(f"<p><b>Dependency manifests:</b> {len(manifests)}<br><b>CI/CD files:</b> {len(ci)}<br><b>Container files:</b> {len(containers)}</p>")
        if manifests: parts.append("<p>"+("<br>".join(html.escape(Path(x).name) for x in manifests[:12]))+"</p>")
        self.dev_manifest.setHtml("".join(parts))

    def generate_ci_template(self,kind):
        folder=QFileDialog.getExistingDirectory(self,"Choose folder for CI template")
        if not folder:return
        path=save_github_template(folder) if kind=="github" else save_gitlab_template(folder)
        QMessageBox.information(self,"DevSecOps",f"Template created:\\n{path}")

    # ---------------- Reports ----------------
    def reports_page(self):
        page=QWidget()
        layout=QVBoxLayout(page)
        layout.setContentsMargins(28,24,28,24)
        layout.addLayout(self.header(
            "Reports & CI/CD Artifacts",
            "Export the active analysis as interactive HTML, PDF, SARIF, JSON or CSV"
        ))
        panel=QFrame(); panel.setObjectName("panel"); pl=QVBoxLayout(panel)
        self.report_summary=QLabel("No active analysis")
        self.report_summary.setObjectName("muted"); pl.addWidget(self.report_summary)

        row=QHBoxLayout()
        buttons=[
            ("Interactive HTML",self.export_html_report),
            ("Executive PDF",self.export_pdf_report),
            ("SARIF 2.1.0",self.export_sarif_report),
            ("JSON",self.export_json_report),
            ("CSV",self.export_csv_report),
        ]
        for label,fn in buttons:
            b=QPushButton("Export "+label)
            if label=="Interactive HTML": b.setObjectName("primary")
            b.clicked.connect(fn); row.addWidget(b)
        row.addStretch(); pl.addLayout(row)
        layout.addWidget(panel)

        info=QFrame(); info.setObjectName("panel"); il=QVBoxLayout(info)
        il.addWidget(QLabel("DevSecOps Usage"))
        note=QLabel(
            "SARIF is intended for compatible code-scanning workflows. "
            "HTML/PDF are suitable for reviewers and stakeholders. "
            "JSON/CSV support automation and downstream analysis."
        )
        note.setWordWrap(True); note.setObjectName("muted"); il.addWidget(note)
        layout.addWidget(info); layout.addStretch()
        return page

    # ---------------- History ----------------
    def history_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28,24,28,24)
        layout.addLayout(self.header(
            "Scan History",
            "Every scan is automatically saved. Double-click a row to restore the full analysis."
        ))
        self.history_table = QTableWidget(0,8)
        self.history_table.setHorizontalHeaderLabels(["Project","Files","Findings","Critical","High","Medium","Gate","Date"])
        self.history_table.horizontalHeader().setSectionResizeMode(0,QHeaderView.Stretch)
        self.history_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.history_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.history_table.doubleClicked.connect(self.load_selected_history)
        layout.addWidget(self.history_table)

        row = QHBoxLayout()
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self.refresh_history)
        open_html = QPushButton("Open Saved HTML Report")
        open_html.clicked.connect(self.open_selected_saved_report)
        row.addWidget(refresh)
        row.addWidget(open_html)
        row.addStretch()
        layout.addLayout(row)
        return page

    # ---------------- About ----------------
    def about_page(self):
        return AboutPanel(self.asset("logo.svg"))

    # ---------------- Scan flow ----------------
    def choose_target(self):
        folder = QFileDialog.getExistingDirectory(self,"Select source project")
        if folder:
            self.path_edit.setText(folder)

    def start_scan(self):
        target = self.path_edit.text().strip()
        if not target or not Path(target).exists():
            QMessageBox.warning(self,"SumScan SastBot","Choose a valid project directory.")
            return

        enabled = [pid for pid,cb in self.engine_checks.items() if cb.isChecked()]
        self.current_target = target
        self.current_session_id = None
        self.run_btn.setEnabled(False)
        self.progress.setValue(0)
        self.live_progress.setValue(0)
        self.live_engine.setText("● SCANNING")
        self.live_engine.setStyleSheet("color:#62E6FF;font-weight:800")
        self.live_project.setText("Project: "+Path(target).name)
        self.status.setText("Scanning")
        self.activity.clear()
        self.activity.append(f"Target: {target}")
        self.activity.append("LIVE ANALYSIS • Background worker started.")
        self.activity.append("SUMI • Reading project files and dispatching enabled analysis engines…")
        if hasattr(self, "sumi_mascot"):
            self.sumi_mascot.set_scanning(True)
            self.sumi_mascot.set_alert(False)
            self.sumi_drawer.say(
                "Analysis Running",
                "I’m scanning the selected project. The interface will remain responsive.",
                "SCANNING"
            )
            self.voice_engine.speak(
                "Analysis started. I am scanning the selected source code now."
            )


        self.thread = QThread(self)
        self.worker = ScanWorker(target,enabled)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.on_progress)
        self.worker.finished.connect(self.on_finished)
        self.worker.failed.connect(self.on_failed)
        self.worker.finished.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.start()

    def on_progress(self,pct,message):
        self.progress.setValue(pct)
        self.live_progress.setValue(pct)
        self.live_file.setText(message)
        self.status.setText(f"{pct}%")
        self.activity.append(message)

    def on_finished(self,result):
        self.run_btn.setEnabled(True)
        self.progress.setValue(100)
        self.live_progress.setValue(100)
        self.live_engine.setText("● COMPLETE")
        self.live_engine.setStyleSheet("color:#72F0C8;font-weight:800")
        self.live_file.setText("Analysis complete")
        self.status.setText("Complete")

        self.findings = sorted(
            result["findings"],
            key=lambda f:(ORDER.get(f.severity,9),f.file,f.line)
        )
        self.metrics = result.get("metrics") or {}
        self.gate = result.get("quality_gate")

        for warning in result.get("warnings",[]):
            self.activity.append("Notice: " + warning)

        files = self.metrics.get("files_scanned", self.metrics.get("python_files", 0))
        item = save_scan(
            self.current_target,
            files,
            self.findings,
            metrics=self.metrics,
            gate=self.gate,
        )
        self.current_session_id = item["session_id"]

        self.activity.append(f"Saved session: {self.current_session_id}")
        self.activity.append(f"Unified findings: {len(self.findings)}")

        self.update_views()
        self.refresh_history()
        self.set_page(3)

    def on_failed(self,message):
        self.run_btn.setEnabled(True)
        self.status.setText("Failed")
        self.live_engine.setText("● FAILED")
        self.live_engine.setStyleSheet("color:#FF5C7A;font-weight:800")
        self.live_file.setText(message)
        if hasattr(self, "sumi_mascot"):
            self.sumi_mascot.set_scanning(False)
            self.sumi_mascot.set_alert(True)
            self.sumi_drawer.say("Analysis Error", message, "ERROR")
            self.voice_engine.speak("The analysis stopped because of an error. Please review the error message.")
        QMessageBox.critical(self,"Analysis failed",message)

    # ---------------- View updates ----------------
    def infer_engine(self,finding):
        rule = (finding.rule_id or "").upper()
        if rule.startswith("SEMGREP:"):
            return "Semgrep"
        if rule.startswith("BANDIT:"):
            return "Bandit"
        if rule.startswith("TRIVY"):
            return "Trivy"
        if rule.startswith("GITLEAKS:"):
            return "Gitleaks"
        if "AST" in rule:
            return "AST"
        return "Built-in"

    def update_views(self):
        counts = {"Critical":0,"High":0,"Medium":0,"Low":0}
        for f in self.findings:
            counts[f.severity] = counts.get(f.severity,0) + 1
        for severity,count in counts.items():
            self.cards[severity].value.setText(str(count))
        self.cards["Total"].value.setText(str(len(self.findings)))

        if self.gate:
            passed = self.gate.status == "PASSED"
            warning = self.gate.status == "WARNING"
            color = "#22c55e" if passed else "#facc15" if warning else "#ff5c7a"
            self.quality_icon.setStyleSheet(f"font-size:26px;color:{color}")
            self.quality_text.setText(
                f"<b>{html.escape(self.gate.status)}</b><br>"
                f"<span style='color:#8ea3bd'>{html.escape(self.gate.reason)}</span>"
            )
            self.score_value.setText(f"{self.gate.score}/100")
            self.debt_value.setText(f"{self.gate.technical_debt_minutes/60:.1f} h")
        else:
            self.score_value.setText("—")
            self.debt_value.setText("—")

        self.complexity_value.setText(str(self.metrics.get("avg_complexity","—")))
        self.hotspot_value.setText(str(counts["Critical"] + counts["High"]))
        self.target_label.setText(self.current_target or "No active project")
        self.report_summary.setText(
            f"{len(self.findings)} findings • "
            f"Gate {getattr(self.gate,'status','N/A')} • "
            f"Session {self.current_session_id or 'unsaved'}"
        )

        extensions = sorted({Path(f.file).suffix.lower() or "(none)" for f in self.findings})
        current = self.extension_filter.currentText()
        self.extension_filter.blockSignals(True)
        self.extension_filter.clear()
        self.extension_filter.addItem("All extensions")
        self.extension_filter.addItems(extensions)
        if current in extensions:
            self.extension_filter.setCurrentText(current)
        self.extension_filter.blockSignals(False)

        self.apply_filters()
        if hasattr(self,"dev_lang"):
            self.refresh_devsecops()

    def apply_filters(self):
        query = self.search.text().lower().strip()
        severity = self.severity_filter.currentText()
        engine = self.engine_filter.currentText()
        extension = self.extension_filter.currentText()

        filtered = []
        for finding in self.findings:
            haystack = f"{finding.title} {finding.rule_id} {finding.file} {finding.snippet}".lower()
            if query and query not in haystack:
                continue
            if severity != "All severities" and finding.severity != severity:
                continue
            inferred_engine = self.infer_engine(finding)
            if engine != "All engines" and inferred_engine != engine:
                continue
            if extension != "All extensions" and Path(finding.file).suffix.lower() != extension:
                continue
            filtered.append(finding)

        self.filtered = filtered
        self.findings_table.setRowCount(len(filtered))
        for row,finding in enumerate(filtered):
            values = [
                finding.severity,
                self.infer_engine(finding),
                finding.language,
                finding.title,
                Path(finding.file).name,
                str(finding.line),
                finding.rule_id,
            ]
            for col,value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if col == 0:
                    item.setForeground(QColor(ACCENT.get(finding.severity,"#e8eef8")))
                self.findings_table.setItem(row,col,item)
        if filtered:
            self.findings_table.selectRow(0)
        else:
            self.detail.setPlainText("No findings match the selected filters.")
            self.source_view.clear()
            self.fix_view.clear()

    def render_selected(self):
        rows = self.findings_table.selectionModel().selectedRows()
        if not rows:
            return
        index = rows[0].row()
        if index >= len(self.filtered):
            return

        finding = self.filtered[index]
        ref_url = reference_url(finding.reference)
        ref_html = (
            f'<a href="{html.escape(ref_url)}">{html.escape(finding.reference)}</a>'
            if ref_url else html.escape(finding.reference)
        )
        self.detail.setHtml(
            f"<h2>{html.escape(finding.title)}</h2>"
            f"<p><b style='color:{ACCENT.get(finding.severity,'#fff')}'>{html.escape(finding.severity)}</b>"
            f" &nbsp; {html.escape(self.infer_engine(finding))}"
            f" &nbsp; {html.escape(finding.rule_id)}</p>"
            f"<p><b>File:</b> {html.escape(finding.file)}<br><b>Line:</b> {finding.line}</p>"
            f"<h3>Why it matters</h3><p>{html.escape(finding.description)}</p>"
            f"<h3>Impact</h3><p>{html.escape(finding.impact)}</p>"
            f"<h3>Reference</h3><p>{ref_html}</p>"
        )

        self.source_view.setHtml(self.source_html(finding))
        self.sumi_drawer.say(
            "Finding Selected",
            f"<b>{finding.severity}</b> • {finding.reference}<br>{finding.title}<br><br>"
            "Choose <b>Ask SUMI</b> for an explanation or <b>Secure Fix Preview</b> to review a safer code suggestion.",
            "READY"
        )
        self.fix_view.setHtml(
            "<h3>Fix Recommendation</h3>"
            f"<p>{html.escape(finding.recommendation)}</p>"
            "<p style='color:#8ea3bd'>Review the suggested change before applying it. "
            "SumScan does not automatically rewrite production source code.</p>"
        )

    def source_html(self,finding,radius=8):
        path = Path(finding.file)
        try:
            lines = path.read_text(encoding="utf-8",errors="replace").splitlines()
        except Exception:
            return "<p>Source file is unavailable.</p>"

        start = max(0,finding.line-1-radius)
        end = min(len(lines),finding.line+radius)
        severity_bg = {
            "Critical":"#4a1522",
            "High":"#402318",
            "Medium":"#393018",
            "Low":"#16321f",
        }.get(finding.severity,"#172033")

        rows = []
        for idx in range(start,end):
            line_no = idx + 1
            active = line_no == finding.line
            bg = severity_bg if active else "transparent"
            marker = "▶" if active else ""
            rows.append(
                f"<div style='background:{bg};padding:2px 6px;'>"
                f"<span style='color:#64748b;display:inline-block;width:52px'>{marker} {line_no}</span>"
                f"<code>{html.escape(lines[idx])}</code></div>"
            )
        return "<div style='font-family:Consolas,monospace'>" + "".join(rows) + "</div>"

    def open_secure_fix(self):
        rows=self.findings_table.selectionModel().selectedRows()
        if not rows or not self.filtered:
            QMessageBox.information(self,"Secure Fix","Select a finding first.")
            self.voice_engine.speak("Please select a finding first, then I can prepare a secure fix preview.")
            return
        finding=self.filtered[rows[0].row()]
        proposal=propose_fix(finding)
        self.secure_fix_drawer.set_proposal(finding,proposal); self.position_secure_fix_drawer(); self.sumi_mascot.set_thinking()
        if proposal.supported:
            self.sumi_drawer.say("Secure Fix Ready",f"I prepared a <b>{proposal.confidence}</b> confidence fix preview. Review or edit the suggested code before applying it.","REVIEW")
            self.voice_engine.speak("I prepared a secure fix preview. I have not changed your source code. Please review or edit the suggestion before applying it.")
        else:
            self.sumi_drawer.say("Manual Fix Recommended","I do not have a safe deterministic rewrite for this finding. Please use the remediation guidance and make a reviewed manual change.","GUIDANCE")
            self.voice_engine.speak("This finding needs a manual secure coding change. I will show remediation guidance but I will not pretend an automatic rewrite is safe.")

    def apply_secure_fix(self,replacement):
        if not self.secure_fix_drawer.current:return
        finding,proposal=self.secure_fix_drawer.current
        answer=QMessageBox.question(self,"SUMI • Confirm Local Code Change",
            f"This changes the LOCAL working copy only.\n\nFile: {finding.file}\nLine: {finding.line}\n\nNo GitHub push will occur. Apply this reviewed change?",
            QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
        if answer!=QMessageBox.Yes:
            self.voice_engine.speak("Okay. I did not change the source code."); return
        try:
            apply_line_replacement(finding.file,finding.line,proposal.before,replacement)
            self.sumi_mascot.set_happy()
            QMessageBox.information(self,"Secure Fix","Local working copy updated. Re-scan the project to verify the finding.")
            self.sumi_drawer.say("Local Fix Applied","The local file was updated. The remote GitHub repository was not modified. Re-scan now to verify the fix.","VERIFY")
            self.voice_engine.speak("The local fix is applied. I did not push anything to GitHub. I recommend a verification re-scan now.")
        except Exception as exc:
            QMessageBox.critical(self,"Secure Fix",str(exc)); self.voice_engine.speak("I could not apply that change safely. Please review the error.")

    def rescan_after_fix(self):
        if not self.current_target:return
        if QMessageBox.question(self,"SUMI • Verify Fix","Re-scan the current project to verify the secure code change?",QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)==QMessageBox.Yes:
            self.secure_fix_drawer.hide()
            self.voice_engine.speak("Starting verification scan. I will check whether the finding is still present.")
            self.start_scan()

    # ---------------- Persistent History ----------------
    def refresh_history(self):
        history = load_history()

        self.dash_history.setRowCount(len(history[:12]))
        for row,item in enumerate(history[:12]):
            gate = (item.get("quality_gate") or {}).get("status","N/A")
            values = [
                Path(item["target"]).name or item["target"],
                str(item.get("files",0)),
                str(item.get("findings",0)),
                gate,
                item.get("date","").replace("T"," "),
            ]
            for col,value in enumerate(values):
                cell = QTableWidgetItem(value)
                cell.setData(Qt.UserRole,item.get("session_id"))
                self.dash_history.setItem(row,col,cell)

        self.history_table.setRowCount(len(history))
        for row,item in enumerate(history):
            counts = item.get("counts") or {}
            gate = (item.get("quality_gate") or {}).get("status","N/A")
            values = [
                Path(item["target"]).name or item["target"],
                str(item.get("files",0)),
                str(item.get("findings",0)),
                str(counts.get("Critical",0)),
                str(counts.get("High",0)),
                str(counts.get("Medium",0)),
                gate,
                item.get("date","").replace("T"," "),
            ]
            for col,value in enumerate(values):
                cell = QTableWidgetItem(value)
                cell.setData(Qt.UserRole,item.get("session_id"))
                self.history_table.setItem(row,col,cell)

    def selected_session_id(self, table):
        row = table.currentRow()
        if row < 0:
            return None
        item = table.item(row,0)
        return item.data(Qt.UserRole) if item else None

    def load_history_from_dashboard(self):
        session_id = self.selected_session_id(self.dash_history)
        if session_id:
            self.restore_session(session_id)

    def load_selected_history(self):
        session_id = self.selected_session_id(self.history_table)
        if session_id:
            self.restore_session(session_id)

    def restore_session(self,session_id):
        payload = load_session(session_id)
        if not payload:
            QMessageBox.warning(self,"History","Saved session could not be loaded.")
            return

        self.current_session_id = session_id
        self.current_target = payload.get("target","")
        self.metrics = payload.get("metrics") or {}
        gate_data = payload.get("quality_gate") or {}

        class Gate:
            pass
        gate = Gate()
        gate.status = gate_data.get("status","N/A")
        gate.score = gate_data.get("score",0)
        gate.reason = gate_data.get("reason","Loaded saved analysis.")
        gate.technical_debt_minutes = gate_data.get("technical_debt_minutes",0)
        self.gate = gate

        self.findings = []
        for item in payload.get("findings",[]):
            self.findings.append(Finding(
                item.get("rule_id",""),
                item.get("language",""),
                item.get("title",""),
                item.get("severity","Low"),
                item.get("file",""),
                int(item.get("line",1)),
                item.get("snippet",""),
                item.get("description",""),
                item.get("impact",""),
                item.get("recommendation",""),
                item.get("reference",""),
            ))
        self.findings.sort(key=lambda f:(ORDER.get(f.severity,9),f.file,f.line))
        self.update_views()
        if hasattr(self, "sumi_mascot"):
            self.sumi_mascot.set_scanning(False)
            critical_count = sum(1 for f in self.findings if f.severity == "Critical")
            self.sumi_mascot.set_alert(critical_count > 0)
            self.sumi_drawer.say(
                "Analysis Complete",
                f"Found <b>{len(self.findings)}</b> issue(s), including "
                f"<b>{critical_count}</b> critical finding(s).",
                "COMPLETE"
            )
            if critical_count:
                self.sumi_mascot.set_alert(True)
                self.voice_engine.speak(
                    f"Analysis complete. I found {len(self.findings)} findings, "
                    f"including {critical_count} critical findings. "
                    "Please review the critical issues first."
                )
            else:
                self.sumi_mascot.set_happy()
                self.voice_engine.speak(
                    f"Analysis complete. I found {len(self.findings)} findings. "
                    "You can select any finding and ask me to explain it."
                )
        self.set_page(3)

    def open_selected_saved_report(self):
        session_id = self.selected_session_id(self.history_table)
        if not session_id:
            QMessageBox.information(self,"History","Select a saved scan first.")
            return
        path = session_report_path(session_id)
        if path.exists():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
        else:
            QMessageBox.warning(self,"History","Saved HTML report was not found.")

    # ---------------- Export ----------------
    def current_payload(self):
        return result_payload(
            self.current_target,
            self.findings,
            self.metrics,
            self.gate,
            self.current_session_id,
        )

    def ensure_results(self):
        if not self.findings:
            QMessageBox.information(self,"Reports","Run or restore an analysis first.")
            return False
        return True

    def export_html_report(self):
        if not self.ensure_results():
            return
        filename,_ = QFileDialog.getSaveFileName(self,"Export HTML","sumscan-sast-report.html","HTML (*.html)")
        if filename:
            export_html(filename,self.current_payload())

    def export_pdf_report(self):
        if not self.ensure_results(): return
        filename,_=QFileDialog.getSaveFileName(self,"Export PDF","sumscan-sastbot-report.pdf","PDF (*.pdf)")
        if filename:
            export_pdf(filename,self.current_target,self.findings,self.metrics,self.gate)
            QMessageBox.information(self,"Reports","PDF report exported successfully.")

    def export_json_report(self):
        if not self.ensure_results():
            return
        filename,_ = QFileDialog.getSaveFileName(self,"Export JSON","sumscan-sast-report.json","JSON (*.json)")
        if filename:
            export_json(filename,self.current_payload())

    def export_csv_report(self):
        if not self.ensure_results():
            return
        filename,_ = QFileDialog.getSaveFileName(self,"Export CSV","sumscan-sast-report.csv","CSV (*.csv)")
        if filename:
            export_csv(filename,self.findings)

    def export_sarif_report(self):
        if not self.ensure_results():
            return
        filename,_ = QFileDialog.getSaveFileName(self,"Export SARIF","sumscan-sast-report.sarif","SARIF (*.sarif *.json)")
        if filename:
            export_sarif(filename,self.current_target,self.findings)
