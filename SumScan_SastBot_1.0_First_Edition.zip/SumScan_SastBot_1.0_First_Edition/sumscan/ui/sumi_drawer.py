# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
# =============================================================================

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QFrame, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTextBrowser, QCheckBox, QComboBox

class SumiDrawer(QFrame):
    action_requested = Signal(str)
    mute_changed = Signal(bool)
    test_voice_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("panel")
        self.setFixedWidth(365)
        layout = QVBoxLayout(self)

        top = QHBoxLayout()
        title = QLabel("SUMI • SECURITY GUIDE")
        title.setStyleSheet("font-size:15px;font-weight:800;letter-spacing:1px;color:#9FD3FF")
        self.state = QLabel("● READY")
        self.state.setStyleSheet("color:#72F0C8;font-weight:800")
        top.addWidget(title)
        top.addStretch()
        top.addWidget(self.state)
        layout.addLayout(top)

        self.message = QTextBrowser()
        self.message.setHtml(
            "<h3>Hi! I’m SUMI.</h3>"
            "<p>I can guide your scan, explain findings, read important alerts aloud, "
            "and help you navigate reports.</p>"
        )
        layout.addWidget(self.message, 1)

        self.voice_box = QCheckBox("SUMI voice enabled")
        self.voice_box.setChecked(True)
        self.voice_box.toggled.connect(lambda checked: self.mute_changed.emit(not checked))
        layout.addWidget(self.voice_box)

        self.neural_box = QCheckBox("Natural neural voice (internet)")
        self.neural_box.setChecked(True)
        layout.addWidget(self.neural_box)

        voice_row = QHBoxLayout()
        voice_row.addWidget(QLabel("Voice"))
        self.voice_selector = QComboBox()
        self.voice_selector.addItems([
            "Ava • Natural",
            "Jenny • Friendly",
            "Aria • Warm",
            "Sonia • British",
        ])
        voice_row.addWidget(self.voice_selector, 1)
        layout.addLayout(voice_row)
        test_voice = QPushButton("🔊 Test Selected Voice")
        test_voice.clicked.connect(self.test_voice_requested.emit)
        layout.addWidget(test_voice)


        for text, action in [
            ("Guide My First Scan", "guide"),
            ("Explain Selected Finding", "explain"),
            ("Review Critical Issues", "critical"),
            ("Open Reports", "reports"),
        ]:
            button = QPushButton(text)
            button.clicked.connect(lambda checked=False, a=action: self.action_requested.emit(a))
            layout.addWidget(button)

        note = QLabel(
            "Voice uses the female Windows voice installed on this PC. "
            "Exact tone depends on the Windows voice package."
        )
        note.setWordWrap(True)
        note.setObjectName("muted")
        layout.addWidget(note)

    def say(self, title, body, state="READY"):
        self.state.setText("● " + state)
        self.message.setHtml(f"<h3>{title}</h3><p>{body}</p>")
