# =============================================================================
# SumScan SastBot 1.0
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
# =============================================================================

import html
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame,QVBoxLayout,QHBoxLayout,QLabel,QTextBrowser,QPushButton

class FindingDrawer(QFrame):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setObjectName("findingDrawer")
        self.setFixedWidth(500)
        lay=QVBoxLayout(self)
        top=QHBoxLayout()
        title=QLabel("FINDING DETAILS • SUMI REMEDIATION")
        title.setStyleSheet("font-weight:850;font-size:15px;color:#79E8FF")
        close=QPushButton("×"); close.setFixedWidth(38); close.clicked.connect(self.hide)
        top.addWidget(title); top.addStretch(); top.addWidget(close); lay.addLayout(top)
        self.view=QTextBrowser(); self.view.setOpenExternalLinks(True); lay.addWidget(self.view,1)

    def show_finding(self,f,engine_name,reference_url=""):
        ref=html.escape(f.reference)
        if reference_url:
            ref=f'<a href="{html.escape(reference_url)}">{ref}</a>'
        self.view.setHtml(f"""
        <h2>{html.escape(f.title)}</h2>
        <p><b>Severity:</b> {html.escape(f.severity)} &nbsp; <b>Engine:</b> {html.escape(engine_name)}</p>
        <p><b>Language:</b> {html.escape(f.language)}<br>
        <b>File:</b> {html.escape(f.file)}<br><b>Line:</b> {f.line}</p>
        <h3>Code Snippet</h3><pre>{html.escape(f.snippet or 'Source context is available in the main viewer.')}</pre>
        <h3>CWE / Reference</h3><p>{ref}</p>
        <h3>Why It Matters</h3><p>{html.escape(f.description)}</p>
        <h3>Potential Impact</h3><p>{html.escape(f.impact)}</p>
        <h3>SUMI Remediation</h3><p>{html.escape(f.recommendation)}</p>
        <p style='color:#8FA9D5'><i>Automated guidance requires manual validation before production changes.</i></p>
        """)
        self.show(); self.raise_()
