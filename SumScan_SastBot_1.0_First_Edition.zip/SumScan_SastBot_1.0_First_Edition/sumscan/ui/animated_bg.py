# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
#
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
#
# Intended for authorized defensive security, secure code review, software
# quality assurance, remediation, and Application Security (AppSec).
# See LICENSE.txt for full terms, limitations, and third-party notices.
# =============================================================================

import random
from PySide6.QtCore import QTimer, QPointF, Qt
from PySide6.QtGui import QPainter, QColor, QPen
from PySide6.QtWidgets import QWidget

class AnimatedBackdrop(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.phase = 0
        self.particles = [[random.random(), random.random(), random.uniform(.2,.6)] for _ in range(34)]
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(50)

    def tick(self):
        self.phase = (self.phase + 2) % max(1, self.height())
        for p in self.particles:
            p[1] += p[2] / 700
            if p[1] > 1:
                p[0], p[1] = random.random(), 0
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        for x,y,speed in self.particles:
            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(56,189,248,42))
            painter.drawEllipse(QPointF(x*self.width(), y*self.height()), 1.2, 1.2)
        painter.setPen(QPen(QColor(99,102,241,25),1))
        painter.drawLine(0,self.phase,self.width(),self.phase)
        painter.setPen(QPen(QColor(56,189,248,9),1))
        for x in range(0,self.width(),54):
            painter.drawLine(x,0,x,self.height())
        for y in range(0,self.height(),54):
            painter.drawLine(0,y,self.width(),y)
