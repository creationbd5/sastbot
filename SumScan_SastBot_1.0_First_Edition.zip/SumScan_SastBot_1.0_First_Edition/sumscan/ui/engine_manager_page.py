# =============================================================================
# SumScan SastBot 1.0
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
# =============================================================================

from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import (
    QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QFrame,QLabel,QPushButton,
    QTextBrowser,QMessageBox,QProgressBar
)
from sumscan.core.engine_manager import ENGINES,status,version,install,update,test
from sumscan.core.platform_utils import detect_platform

class EngineActionWorker(QThread):
    log = Signal(str)
    done = Signal(bool,str)
    def __init__(self,spec,action):
        super().__init__(); self.spec=spec; self.action=action
    def run(self):
        try:
            if self.action=="install":
                ok=install(self.spec,self.log.emit)
                self.done.emit(ok,"Installation complete." if ok else "Installation was not completed.")
            elif self.action=="update":
                ok=update(self.spec,self.log.emit)
                self.done.emit(ok,"Update complete." if ok else "Update requires manual/system package management.")
        except Exception as exc:
            self.done.emit(False,str(exc))

class EngineManagerPage(QWidget):
    def __init__(self,voice=None,parent=None):
        super().__init__(parent); self.voice=voice; self.cards={}; self.worker=None; self.build(); self.refresh()

    def build(self):
        lay=QVBoxLayout(self); lay.setContentsMargins(28,24,28,24)
        title=QLabel("Security Engine Manager")
        title.setStyleSheet("font-size:25px;font-weight:850")
        lay.addWidget(title)
        info=detect_platform()
        subtitle=QLabel(
            f"Platform: {info.distro or info.system.title()} • Install, test and update optional SAST/SCA engines."
        )
        subtitle.setObjectName("muted"); lay.addWidget(subtitle)

        actions=QHBoxLayout()
        recommended=QPushButton("Install Recommended Engines")
        recommended.setObjectName("primary")
        recommended.clicked.connect(self.install_recommended)
        refresh=QPushButton("Refresh Status"); refresh.clicked.connect(self.refresh)
        actions.addWidget(recommended); actions.addWidget(refresh); actions.addStretch()
        lay.addLayout(actions)

        self.grid=QGridLayout()
        lay.addLayout(self.grid)

        self.output=QTextBrowser()
        self.output.setMaximumHeight(180)
        lay.addWidget(self.output)

        self.progress=QProgressBar(); self.progress.setRange(0,1); self.progress.setValue(0)
        lay.addWidget(self.progress)
        lay.addStretch()

    def _card(self,spec,row,col):
        card=QFrame(); card.setObjectName("card"); v=QVBoxLayout(card)
        title=QLabel(spec.name); title.setStyleSheet("font-size:17px;font-weight:800")
        status_label=QLabel(); version_label=QLabel(); version_label.setObjectName("muted")
        desc=QLabel(spec.description); desc.setWordWrap(True); desc.setObjectName("muted")
        rowbox=QHBoxLayout()
        install_btn=QPushButton("Install")
        test_btn=QPushButton("Test")
        update_btn=QPushButton("Update")
        install_btn.clicked.connect(lambda checked=False,s=spec:self.run_action(s,"install"))
        test_btn.clicked.connect(lambda checked=False,s=spec:self.test_engine(s))
        update_btn.clicked.connect(lambda checked=False,s=spec:self.run_action(s,"update"))
        rowbox.addWidget(install_btn); rowbox.addWidget(test_btn); rowbox.addWidget(update_btn)
        v.addWidget(title); v.addWidget(status_label); v.addWidget(version_label); v.addWidget(desc); v.addLayout(rowbox)
        self.cards[spec.key]=(status_label,version_label,install_btn)
        self.grid.addWidget(card,row,col)

    def refresh(self):
        # Build once.
        if not self.cards:
            for i,spec in enumerate(ENGINES):
                self._card(spec,i//2,i%2)
        for spec in ENGINES:
            ok,note=status(spec)
            status_label,version_label,install_btn=self.cards[spec.key]
            status_label.setText("● AVAILABLE" if ok else "○ OPTIONAL / NOT INSTALLED")
            status_label.setStyleSheet(
                "color:#72F0C8;font-weight:800" if ok else "color:#8FA9D5;font-weight:800"
            )
            version_label.setText(version(spec) if ok else note)
            install_btn.setEnabled(not ok)

    def test_engine(self,spec):
        ok,msg=test(spec)
        self.output.append(msg)
        if self.voice:
            self.voice.speak(f"{spec.name} is ready." if ok else f"{spec.name} is not installed yet.")

    def run_action(self,spec,action):
        if self.worker and self.worker.isRunning():
            QMessageBox.information(self,"Engine Manager","Another engine action is still running.")
            return
        if self.voice:
            self.voice.speak(
                f"{action.title()} {spec.name}? I will use the local Python or system package manager. "
                "Please review any operating system permission prompt."
            )
        answer=QMessageBox.question(
            self,"SUMI • Engine Manager",
            f"{action.title()} {spec.name} on this computer?",
            QMessageBox.Yes|QMessageBox.No,QMessageBox.No
        )
        if answer!=QMessageBox.Yes:return
        self.output.clear(); self.progress.setRange(0,0)
        self.worker=EngineActionWorker(spec,action)
        self.worker.log.connect(self.output.append)
        self.worker.done.connect(lambda ok,msg:self.finished_action(ok,msg,spec))
        self.worker.start()

    def finished_action(self,ok,msg,spec):
        self.progress.setRange(0,1); self.progress.setValue(1 if ok else 0)
        self.output.append(msg); self.refresh()
        if self.voice:
            self.voice.speak(
                f"{spec.name} is now available." if ok else
                f"{spec.name} setup was not completed. Review the engine manager message."
            )

    def install_recommended(self):
        missing=[s for s in ENGINES if not status(s)[0]]
        if not missing:
            QMessageBox.information(self,"Engine Manager","All recommended engines are already available.")
            return
        names=", ".join(s.name for s in missing)
        QMessageBox.information(
            self,"Recommended Engines",
            "Missing engines: "+names+
            "\n\nUse each Install button so you can review permissions and installation output."
        )
        if self.voice:
            self.voice.speak(
                f"{len(missing)} recommended engines are missing. "
                "For safety, please install them one at a time and review each permission prompt."
            )
