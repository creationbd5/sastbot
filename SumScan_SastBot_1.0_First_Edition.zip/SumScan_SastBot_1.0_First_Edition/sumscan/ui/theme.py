# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
# =============================================================================

THEME = """
QMainWindow, QWidget {
    background: #07111F;
    color: #EAF2FC;
    font-family: "Segoe UI", "Inter", Arial, sans-serif;
    font-size: 13px;
}
QFrame#sidebar {
    background: #081426;
    border-right: 1px solid #24456F;
}
QFrame#panel, QFrame#card {
    background: rgba(12, 27, 48, 238);
    border: 1px solid #294B78;
    border-radius: 12px;
}
QFrame#card:hover {
    border-color: #52B8FF;
    background: rgba(15, 34, 59, 245);
}
QFrame#privacyPanel {
    background: #071F2D;
    border: 1px solid #45D8B8;
    border-radius: 12px;
}
QFrame#liveBar {
    background: #08152B;
    border-top: 1px solid #2D5A99;
    min-height: 32px;
}
QFrame#findingDrawer {
    background: #0A1830;
    border: 1px solid #4B86CC;
    border-radius: 14px;
}
QLabel#pageTitle {
    font-size: 26px;
    font-weight: 700;
    color: #F8FBFF;
}
QLabel#muted { color: #92A9C7; }
QLabel#statValue {
    font-size: 28px;
    font-weight: 700;
    color: #FFFFFF;
}
QPushButton {
    background: #173A75;
    color: #F8FBFF;
    border: 1px solid #4E8EDB;
    border-radius: 9px;
    padding: 9px 14px;
    font-weight: 600;
}
QPushButton:hover {
    background: #24569B;
    border-color: #6CE5FF;
}
QPushButton:pressed { background: #102C5C; }
QPushButton:disabled {
    color: #6F829D;
    background: #111F36;
    border-color: #253A58;
}
QPushButton#primary {
    background: #5948C9;
    border-color: #7DE7FF;
}
QPushButton#primary:hover {
    background: #735DE2;
    border-color: #B0F5FF;
}
QPushButton#nav {
    text-align: left;
    background: transparent;
    border: 1px solid transparent;
    border-radius: 9px;
    padding: 11px 14px;
    min-height: 24px;
    font-size: 14px;
}
QPushButton#nav:hover { background: #122A4D; }
QPushButton#nav:checked {
    background: #17375F;
    border-left: 3px solid #5BE4FF;
}
QLineEdit, QComboBox, QTextEdit, QTextBrowser, QPlainTextEdit {
    background: #09172A;
    color: #F3F8FF;
    border: 1px solid #2D4B73;
    border-radius: 8px;
    padding: 8px;
    selection-background-color: #315E9A;
}
QLineEdit:focus, QComboBox:focus, QTextEdit:focus, QPlainTextEdit:focus {
    border-color: #61CAFF;
}
QComboBox QAbstractItemView {
    background: #0D1D35;
    color: #F5F8FF;
    selection-background-color: #24528A;
    selection-color: #FFFFFF;
    border: 1px solid #3B669C;
    outline: 0;
}
QComboBox QAbstractItemView::item {
    min-height: 28px;
    padding-left: 8px;
}
QProgressBar {
    background: #09172A;
    border: 1px solid #2D4B73;
    border-radius: 7px;
    text-align: center;
    min-height: 17px;
}
QProgressBar::chunk {
    background: #4F79E8;
    border-radius: 6px;
}
QTableWidget {
    background: #081525;
    alternate-background-color: #0B1B30;
    border: 1px solid #294B78;
    border-radius: 9px;
    gridline-color: #1C304B;
    selection-background-color: #234A78;
}
QTableWidget::item { padding: 6px; }
QTableWidget::item:hover { background: #132D4D; }
QHeaderView::section {
    background: #10243D;
    color: #D5E3F4;
    padding: 8px;
    border: none;
    border-bottom: 1px solid #31537E;
    font-weight: 600;
}
QScrollBar:vertical {
    background: #081321;
    width: 10px;
}
QScrollBar::handle:vertical {
    background: #315178;
    border-radius: 5px;
    min-height: 28px;
}
QToolTip {
    background: #102541;
    color: #F4F9FF;
    border: 1px solid #5BCFFF;
    padding: 6px;
}
QCheckBox { spacing: 8px; }
QCheckBox::indicator { width: 16px; height: 16px; }
QDialog QLineEdit { min-height: 30px; }
"""
