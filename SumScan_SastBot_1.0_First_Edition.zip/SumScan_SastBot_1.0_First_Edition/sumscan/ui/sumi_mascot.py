# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
# =============================================================================

from PySide6.QtCore import Qt, QTimer, Signal, QRectF, QPointF
from PySide6.QtGui import QPainter, QColor, QPen, QBrush, QRadialGradient, QCursor
from PySide6.QtWidgets import QWidget

class SumiMascot(QWidget):
    clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(190, 220)
        self.phase = 0
        self.state = "idle"  # idle, talking, scanning, alert, thinking, happy
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(45)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("SUMI • SumScan Security Guide")

    def set_state(self, state):
        self.state = state
        self.update()

    def set_talking(self, value):
        if value:
            self.set_state("talking")
        elif self.state == "talking":
            self.set_state("idle")

    def set_scanning(self, value):
        self.set_state("scanning" if value else "idle")

    def set_alert(self, value):
        if value:
            self.set_state("alert")
        elif self.state == "alert":
            self.set_state("idle")

    def set_happy(self):
        self.set_state("happy")
        QTimer.singleShot(2200, lambda: self.set_state("idle"))

    def set_thinking(self):
        self.set_state("thinking")

    def tick(self):
        self.phase = (self.phase + 1) % 360
        self.update()

    def mousePressEvent(self, event):
        self.clicked.emit()

    def _eye_offset(self):
        # Eyes follow the global mouse pointer.
        local = self.mapFromGlobal(QCursor.pos())
        dx = local.x() - self.width()/2
        dy = local.y() - 68
        scale = max(1.0, (dx*dx + dy*dy) ** 0.5)
        return QPointF(max(-4,min(4,dx/scale*4)), max(-3,min(3,dy/scale*3)))

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        # Larger pseudo-3D presentation while preserving crisp vector animation.
        p.scale(1.24, 1.24)

        bob = 3 * __import__("math").sin(self.phase / 24)
        cx = self.width()/2
        cy = 68 + bob

        # Large animated aura
        glow = QRadialGradient(cx,cy,72)
        palette = {
            "alert": (QColor(255,76,125,115), QColor(128,23,69,0)),
            "scanning": (QColor(71,220,255,120), QColor(38,97,255,0)),
            "thinking": (QColor(160,103,255,105), QColor(75,39,160,0)),
            "happy": (QColor(90,244,190,105), QColor(30,110,85,0)),
        }
        a,b = palette.get(self.state,(QColor(69,149,255,105),QColor(101,70,255,0)))
        glow.setColorAt(0,a); glow.setColorAt(.7,QColor(a.red(),a.green(),a.blue(),28)); glow.setColorAt(1,b)
        p.setBrush(glow); p.setPen(Qt.NoPen)
        p.drawEllipse(QRectF(4,4,142,142))

        # Female-inspired antenna "hair ribbon" silhouette
        p.setPen(QPen(QColor("#A7D5FF"),3))
        p.drawLine(cx-22,cy-38,cx-31,cy-57)
        p.drawLine(cx+22,cy-38,cx+31,cy-57)
        p.setBrush(QColor("#70E7FF")); p.setPen(Qt.NoPen)
        p.drawEllipse(QRectF(cx-35,cy-61,8,8)); p.drawEllipse(QRectF(cx+27,cy-61,8,8))
        p.setBrush(QColor("#B070FF"))
        p.drawEllipse(QRectF(cx+33,cy-48,12,7))
        p.drawEllipse(QRectF(cx+41,cy-45,7,12))

        # Head
        p.setBrush(QColor("#EDF7FF")); p.setPen(QPen(QColor("#538EFF"),3))
        p.drawRoundedRect(QRectF(cx-43,cy-38,86,72),30,30)

        # Soft side ear modules
        p.setBrush(QColor("#1C3475")); p.setPen(QPen(QColor("#62DFFF"),2))
        p.drawEllipse(QRectF(cx-49,cy-11,14,27)); p.drawEllipse(QRectF(cx+35,cy-11,14,27))

        # Visor
        p.setBrush(QColor("#07152F")); p.setPen(QPen(QColor("#294C88"),2))
        p.drawRoundedRect(QRectF(cx-34,cy-26,68,43),18,18)

        off = self._eye_offset()
        blink = self.phase % 150 in (0,1,2,3,4)
        eye = QColor("#62EDFF")
        if self.state == "alert":
            # surprised alert eyes
            p.setBrush(eye); p.setPen(Qt.NoPen)
            p.drawEllipse(QRectF(cx-22+off.x(),cy-11+off.y(),11,15))
            p.drawEllipse(QRectF(cx+11+off.x(),cy-11+off.y(),11,15))
        elif self.state == "happy":
            p.setPen(QPen(eye,4))
            p.drawArc(QRectF(cx-23,cy-8,15,13),15*16,150*16)
            p.drawArc(QRectF(cx+8,cy-8,15,13),15*16,150*16)
        elif blink:
            p.setPen(QPen(eye,4))
            p.drawLine(cx-22,cy-2,cx-11,cy-2)
            p.drawLine(cx+11,cy-2,cx+22,cy-2)
        else:
            p.setBrush(eye); p.setPen(Qt.NoPen)
            p.drawEllipse(QRectF(cx-22+off.x(),cy-8+off.y(),9,12))
            p.drawEllipse(QRectF(cx+13+off.x(),cy-8+off.y(),9,12))

        # Expressive brows
        if self.state == "thinking":
            p.setPen(QPen(QColor("#C1CFFF"),2))
            p.drawLine(cx-24,cy-17,cx-13,cy-20)
            p.drawLine(cx+13,cy-20,cx+24,cy-17)
        elif self.state == "alert":
            p.setPen(QPen(QColor("#FF7EA0"),2))
            p.drawLine(cx-24,cy-18,cx-14,cy-22)
            p.drawLine(cx+14,cy-22,cx+24,cy-18)

        # Mouth
        p.setPen(QPen(QColor("#78F0D2"),3))
        if self.state == "talking":
            mouth_h = 5 + (self.phase % 4)*2
            p.drawEllipse(QRectF(cx-8,cy+6,16,mouth_h))
        elif self.state == "alert":
            p.drawEllipse(QRectF(cx-5,cy+7,10,11))
        elif self.state == "thinking":
            p.drawLine(cx-6,cy+12,cx+6,cy+10)
        else:
            p.drawArc(QRectF(cx-11,cy+3,22,14),190*16,160*16)

        # Neck/body
        p.setBrush(QColor("#142B69")); p.setPen(QPen(QColor("#806CFF"),2))
        p.drawRoundedRect(QRectF(cx-29,cy+38,58,43),15,15)

        # Shoulder pads
        p.setBrush(QColor("#D9ECFF")); p.setPen(QPen(QColor("#4F8AFF"),2))
        p.drawEllipse(QRectF(cx-41,cy+43,18,17)); p.drawEllipse(QRectF(cx+23,cy+43,18,17))

        # Chest logo
        p.setBrush(QColor("#081A3C")); p.setPen(QPen(QColor("#5FE7FF"),2))
        p.drawEllipse(QRectF(cx-14,cy+47,28,26))
        p.setPen(QPen(QColor("#73F0D5"),2))
        p.drawLine(cx-8,cy+60,cx-2,cy+54)
        p.drawLine(cx-2,cy+54,cx+4,cy+60)
        p.drawLine(cx+4,cy+60,cx+9,cy+55)

        # Pseudo-3D shell highlights
        p.setPen(QPen(QColor(255,255,255,90), 1.5))
        p.drawArc(QRectF(cx-35,cy-31,52,32), 55*16, 92*16)
        p.setPen(QPen(QColor(96,232,255,70), 2))
        p.drawArc(QRectF(cx-26,cy+40,48,35), 195*16, 110*16)

        # State animation
        if self.state == "scanning":
            sy = cy + 41 + (self.phase % 34)
            if sy < cy + 78:
                p.setPen(QPen(QColor(86,229,255,180),2))
                p.drawLine(cx-25,sy,cx+25,sy)
        elif self.state == "thinking":
            p.setBrush(QColor("#A875FF")); p.setPen(Qt.NoPen)
            for i,r in enumerate((3,4,5)):
                p.drawEllipse(QPointF(cx+47+i*8,cy-22-i*8),r,r)
        elif self.state == "happy":
            p.setPen(QPen(QColor("#71F1C8"),2))
            p.drawLine(cx-50,cy+5,cx-58,cy-2)
            p.drawLine(cx+50,cy+5,cx+58,cy-2)
