# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
#
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
#
# Intended for authorized defensive security, secure code review, software
# quality assurance, remediation, and Application Security (AppSec).
# See LICENSE.txt for full terms, limitations, and third-party notices.
# =============================================================================

from datetime import datetime
from pathlib import Path
import json
import re

from .reports import result_payload, export_json, export_csv, export_sarif, export_html

def _app_root():
    # Prefer a visible history folder beside the application.
    candidate = Path(__file__).resolve().parents[2] / "history"
    try:
        candidate.mkdir(parents=True, exist_ok=True)
        test = candidate / ".write_test"
        test.write_text("ok", encoding="utf-8")
        test.unlink(missing_ok=True)
        return candidate
    except Exception:
        fallback = Path.home() / ".sumscan_sast" / "history"
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback

HISTORY_DIR = _app_root()
INDEX_FILE = HISTORY_DIR / "index.json"

def _slug(value):
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", value or "project").strip("_")
    return value[:60] or "project"

def load_history():
    try:
        return json.loads(INDEX_FILE.read_text(encoding="utf-8"))
    except Exception:
        return []

def save_scan(target, files_scanned, findings, metrics=None, gate=None):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    project = _slug(Path(target).name or "project")
    session_id = f"{timestamp}_{project}"
    session_dir = HISTORY_DIR / session_id
    session_dir.mkdir(parents=True, exist_ok=True)

    payload = result_payload(target, findings, metrics or {"files_scanned": files_scanned}, gate, session_id)
    export_json(session_dir / "session.json", payload)
    export_json(session_dir / "findings.json", {"findings": payload["findings"]})
    export_csv(session_dir / "report.csv", findings)
    export_sarif(session_dir / "report.sarif", target, findings)
    export_html(session_dir / "report.html", payload)

    counts = {"Critical":0,"High":0,"Medium":0,"Low":0}
    for finding in findings:
        counts[finding.severity] = counts.get(finding.severity, 0) + 1

    item = {
        "session_id": session_id,
        "date": payload["generated_at"],
        "target": target,
        "files": files_scanned,
        "findings": len(findings),
        "counts": counts,
        "quality_gate": payload.get("quality_gate") or {},
        "session_path": str(session_dir),
    }

    history = load_history()
    history.insert(0, item)
    INDEX_FILE.write_text(json.dumps(history[:500], indent=2), encoding="utf-8")
    return item

def load_session(session_id):
    session = HISTORY_DIR / session_id / "session.json"
    if not session.exists():
        return None
    try:
        return json.loads(session.read_text(encoding="utf-8"))
    except Exception:
        return None

def session_report_path(session_id):
    return HISTORY_DIR / session_id / "report.html"
