# =============================================================================
# SumScan SastBot 1.0
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
# =============================================================================

import os
import platform
import shutil
import subprocess
import sys
from dataclasses import dataclass
from typing import Callable

from .platform_utils import detect_platform

@dataclass
class EngineSpec:
    key: str
    name: str
    executable: str
    install_kind: str
    pip_package: str = ""
    apt_package: str = ""
    description: str = ""

ENGINES = [
    EngineSpec("semgrep","Semgrep","semgrep","pip","semgrep","",
               "Multi-language SAST engine and rule ecosystem."),
    EngineSpec("bandit","Bandit","bandit","pip","bandit","",
               "Python-focused security static analysis."),
    EngineSpec("trivy","Trivy","trivy","system","","trivy",
               "Dependency, filesystem, misconfiguration and secret scanning."),
    EngineSpec("gitleaks","Gitleaks","gitleaks","system","","gitleaks",
               "Repository secret and credential scanning."),
    EngineSpec("treesitter","Tree-sitter Language Pack","","pip","tree-sitter-language-pack","",
               "Multi-language parsing backend for structural analysis."),
]

def _python_cmd():
    return [sys.executable, "-m", "pip"]

def status(spec: EngineSpec):
    if spec.key=="treesitter":
        try:
            import tree_sitter_language_pack  # noqa
            return True, "Python package installed"
        except Exception:
            return False, "Not installed"
    path=shutil.which(spec.executable)
    return (bool(path), path or "Not installed")

def version(spec: EngineSpec):
    ok,note=status(spec)
    if not ok:
        return ""
    if spec.key=="treesitter":
        try:
            import importlib.metadata as md
            return md.version("tree-sitter-language-pack")
        except Exception:
            return "installed"
    for args in ([spec.executable,"--version"],[spec.executable,"version"]):
        try:
            p=subprocess.run(args,capture_output=True,text=True,timeout=20)
            out=(p.stdout or p.stderr or "").strip()
            if out:
                return out.splitlines()[0][:180]
        except Exception:
            pass
    return "installed"

def install(spec: EngineSpec, progress: Callable[[str],None] | None=None):
    info=detect_platform()
    say=progress or (lambda x:None)
    if status(spec)[0]:
        say(f"{spec.name} is already installed.")
        return True

    if spec.install_kind=="pip":
        cmd=_python_cmd()+["install","--upgrade",spec.pip_package]
        say("Running: "+" ".join(cmd))
        p=subprocess.run(cmd,text=True,capture_output=True)
        say((p.stdout or p.stderr or "").strip()[-2000:])
        return p.returncode==0 and status(spec)[0]

    if spec.key=="trivy" and info.is_linux:
        # Try apt package if present in configured repositories.
        cmd=["sudo","apt-get","install","-y","trivy"]
        say("Running: "+" ".join(cmd))
        p=subprocess.run(cmd,text=True,capture_output=True)
        say((p.stdout or p.stderr or "").strip()[-2000:])
        return p.returncode==0 and status(spec)[0]

    if spec.key=="gitleaks" and info.is_linux:
        # Kali/Debian repositories may provide gitleaks. If unavailable, user gets guidance.
        cmd=["sudo","apt-get","install","-y","gitleaks"]
        say("Running: "+" ".join(cmd))
        p=subprocess.run(cmd,text=True,capture_output=True)
        say((p.stdout or p.stderr or "").strip()[-2000:])
        return p.returncode==0 and status(spec)[0]

    if info.is_windows:
        say(
            f"{spec.name} requires a system-level installer on Windows. "
            "Install it with your approved package manager or official release, then click Refresh."
        )
        return False

    say(f"Automatic installation is not configured for {spec.name} on this platform.")
    return False

def update(spec: EngineSpec, progress=None):
    # For pip packages, update = install --upgrade.
    if spec.install_kind=="pip":
        return install(spec,progress)
    if progress:
        progress(
            f"{spec.name} is a system tool. Use the operating system/package-manager update process, then Refresh."
        )
    return False

def test(spec: EngineSpec):
    ok,note=status(spec)
    if not ok:
        return False,f"{spec.name} is not installed."
    return True,f"{spec.name} ready • {version(spec)}"
