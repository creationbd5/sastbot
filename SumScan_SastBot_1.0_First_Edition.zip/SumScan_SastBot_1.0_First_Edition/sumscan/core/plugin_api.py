# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
#
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
#
# Intended for authorized defensive security, secure code review, software
# quality assurance, remediation, and Application Security (AppSec).
# See LICENSE.txt for full terms, limitations, and third-party notices.
# =============================================================================

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

@dataclass
class AnalyzerResult:
    analyzer: str
    findings: list = field(default_factory=list)
    metrics: dict = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)

class AnalyzerPlugin(ABC):
    plugin_id = 'base'
    display_name = 'Base Analyzer'
    category = 'SAST'

    @abstractmethod
    def available(self): ...

    @abstractmethod
    def supports(self, target): ...

    @abstractmethod
    def analyze(self, target): ...
