# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
# =============================================================================

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import os

from .models import Finding
from .rules import RULES

SUPPORTED = {ext for rule in RULES for ext in rule.extensions}
IGNORED = {
    ".git", ".svn", ".hg", ".idea", ".vscode",
    ".venv", "venv", "__pycache__", "node_modules", "vendor",
    "dist", "build", "coverage", ".pytest_cache", ".mypy_cache",
    "target", "bin", "obj"
}
MAX_FILE_BYTES = 2 * 1024 * 1024

LANGUAGES = {
    ".py": "Python",
    ".php": "PHP",
    ".js": "JavaScript", ".jsx": "JavaScript",
    ".ts": "TypeScript", ".tsx": "TypeScript",
    ".java": "Java",
    ".cs": "C#",
    ".go": "Go",
    ".rb": "Ruby",
    ".c": "C", ".h": "C/C++",
    ".cc": "C++", ".cpp": "C++", ".cxx": "C++", ".hpp": "C++",
    ".kt": "Kotlin", ".kts": "Kotlin",
}

def language_for(ext):
    return LANGUAGES.get(ext.lower(), "Other")

def discover_files(target):
    path = Path(target)
    if path.is_file():
        try:
            return [path] if path.suffix.lower() in SUPPORTED and path.stat().st_size <= MAX_FILE_BYTES else []
        except OSError:
            return []

    out = []
    if path.is_dir():
        for p in path.rglob("*"):
            try:
                if not p.is_file() or p.suffix.lower() not in SUPPORTED:
                    continue
                if any(part in IGNORED for part in p.parts):
                    continue
                if p.stat().st_size > MAX_FILE_BYTES:
                    continue
                out.append(p)
            except OSError:
                continue
    return out

def scan_file(path):
    findings = []
    ext = path.suffix.lower()
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return findings

    language = language_for(ext)
    for line_no, line in enumerate(text.splitlines(), 1):
        for rule in RULES:
            if ext not in rule.extensions:
                continue
            if rule.pattern.search(line):
                findings.append(Finding(
                    rule.rule_id,
                    language,
                    rule.title,
                    rule.severity,
                    str(path),
                    line_no,
                    line.strip(),
                    rule.description,
                    rule.impact,
                    rule.recommendation,
                    rule.reference,
                ))
    return findings

def scan_files_parallel(files, progress=None, max_workers=None):
    files = list(files)
    if not files:
        return []

    workers = max_workers or min(16, max(4, (os.cpu_count() or 4)))
    findings = []
    done = 0
    total = len(files)

    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="sumscan") as pool:
        future_map = {pool.submit(scan_file, p): p for p in files}
        for future in as_completed(future_map):
            path = future_map[future]
            try:
                findings.extend(future.result())
            except Exception:
                pass
            done += 1
            if progress:
                progress(int(done / total * 100), str(path))

    findings.sort(key=lambda f: (
        {"Critical":0,"High":1,"Medium":2,"Low":3}.get(f.severity,9),
        f.file, f.line, f.rule_id
    ))
    return findings
