import difflib
import re
from dataclasses import dataclass
from pathlib import Path

@dataclass
class FixProposal:
    supported: bool
    explanation: str
    before: str
    after: str
    diff: str
    confidence: str

def propose_fix(finding):
    before=finding.snippet or ""
    rule=(finding.rule_id or "").upper()
    after=before
    explanation=finding.recommendation
    confidence="Guidance"

    if rule in {"PY-EVAL-001","PY-AST-DYN-001"} and "eval(" in before:
        after=before.replace("eval(","ast.literal_eval(",1)
        explanation="Use ast.literal_eval only when literal data structures are expected. Add import ast if needed and review behavior."
        confidence="Medium"
    elif "SHELL" in rule and "shell=True" in before:
        after=before.replace("shell=True","shell=False",1)
        explanation="Disable shell parsing and review the surrounding call. Convert command strings to validated argument lists when needed."
        confidence="Medium"
    elif "SECRET" in rule or rule in {"GEN-SEC-001","PY-AST-SECRET-001"}:
        m=re.match(r'(\s*)([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([\'"]).*?\3(\s*(?:#.*)?)$',before)
        if m:
            indent,name,quote,tail=m.groups()
            after=f'{indent}{name} = os.getenv("{name}"){tail}'
            explanation="Move the secret outside source control, load it from environment/secret management, and rotate any exposed value. Add import os if needed."
            confidence="High"
    elif rule=="PY-CRYPTO-001":
        new=before.replace("hashlib.md5(","hashlib.sha256(",1).replace("hashlib.sha1(","hashlib.sha256(",1)
        if new!=before:
            after=new
            explanation="Use a stronger hash for general integrity use. For passwords, use a dedicated password-hashing function such as Argon2, bcrypt, or scrypt."
            confidence="Medium"
    elif rule=="GO-TLS-001" and "InsecureSkipVerify" in before:
        after=before.replace("InsecureSkipVerify: true","InsecureSkipVerify: false",1)
        explanation="Keep TLS certificate verification enabled and configure trusted roots/server names."
        confidence="High"

    supported=after!=before
    diff="".join(difflib.unified_diff((before+"\n").splitlines(True),(after+"\n").splitlines(True),fromfile="before",tofile="after")) if supported else ""
    return FixProposal(supported,explanation,before,after,diff,confidence)

def apply_line_replacement(file_path,line_no,expected_before,replacement):
    path=Path(file_path)
    lines=path.read_text(encoding="utf-8",errors="replace").splitlines(True)
    idx=int(line_no)-1
    if idx<0 or idx>=len(lines): raise IndexError("Finding line is outside the current file.")
    current=lines[idx].rstrip("\r\n")
    if current.strip()!=(expected_before or "").strip():
        raise RuntimeError("The source line changed since the scan. Re-scan before applying this fix.")
    ending="\r\n" if lines[idx].endswith("\r\n") else "\n" if lines[idx].endswith("\n") else ""
    lines[idx]=replacement+ending
    path.write_text("".join(lines),encoding="utf-8")
    return str(path)
