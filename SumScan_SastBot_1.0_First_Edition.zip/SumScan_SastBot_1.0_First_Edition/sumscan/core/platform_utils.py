# =============================================================================
# SumScan SastBot 1.0
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
# =============================================================================

import os
import platform
import shutil
import subprocess
from dataclasses import dataclass

@dataclass
class PlatformInfo:
    system: str
    distro: str
    is_windows: bool
    is_linux: bool
    is_kali: bool

def detect_platform():
    system = platform.system().lower()
    distro = ""
    if system == "linux":
        try:
            data={}
            with open("/etc/os-release","r",encoding="utf-8") as f:
                for line in f:
                    if "=" in line:
                        k,v=line.rstrip().split("=",1)
                        data[k]=v.strip('"')
            distro = data.get("ID","") or data.get("NAME","")
        except Exception:
            pass
    return PlatformInfo(
        system=system,
        distro=distro,
        is_windows=system=="windows",
        is_linux=system=="linux",
        is_kali=(system=="linux" and "kali" in distro.lower()),
    )

def executable(name):
    return shutil.which(name) or ""

def run_command(args, timeout=180):
    flags = getattr(subprocess,"CREATE_NO_WINDOW",0) if platform.system().lower()=="windows" else 0
    return subprocess.run(args,capture_output=True,text=True,timeout=timeout,creationflags=flags)
