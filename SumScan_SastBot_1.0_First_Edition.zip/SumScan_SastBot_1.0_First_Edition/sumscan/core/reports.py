# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
#
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
#
# Intended for authorized defensive security, secure code review, software
# quality assurance, remediation, and Application Security (AppSec).
# See LICENSE.txt for full terms, limitations, and third-party notices.
# =============================================================================

from dataclasses import asdict
from datetime import datetime
from pathlib import Path
import csv
import html
import json

from .references import reference_url
from sumscan import __version__

SEVERITY_LEVEL = {
    "Critical": "error",
    "High": "error",
    "Medium": "warning",
    "Low": "note",
}

def result_payload(target, findings, metrics, gate, session_id=None):
    return {
        "product": "SumScan SastBot",
        "copyright": "Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.",
        "author": "Sumon Mahmud",
        "version": __version__,
        "session_id": session_id,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "target": target,
        "metrics": metrics or {},
        "quality_gate": asdict(gate) if hasattr(gate, "__dataclass_fields__") else gate,
        "findings": [f.to_dict() for f in findings],
    }

def export_json(path, payload):
    Path(path).write_text(json.dumps(payload, indent=2), encoding="utf-8")

def export_csv(path, findings):
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow([
            "Severity","Language","Rule","Title","File","Line",
            "Code","Description","Impact","Recommendation","Reference"
        ])
        for f in findings:
            writer.writerow([
                f.severity, f.language, f.rule_id, f.title, f.file, f.line,
                f.snippet, f.description, f.impact, f.recommendation, f.reference
            ])

def export_sarif(path, target, findings):
    rules = {}
    results = []

    for f in findings:
        rule_id = f.rule_id or "SUMSCAN"
        if rule_id not in rules:
            rules[rule_id] = {
                "id": rule_id,
                "name": f.title,
                "shortDescription": {"text": f.title},
                "fullDescription": {"text": f.description},
                "help": {
                    "text": f.recommendation,
                    "markdown": f"{f.recommendation}\n\nReference: {f.reference}"
                },
                "helpUri": reference_url(f.reference) or None,
                "properties": {
                    "security-severity": f.severity,
                    "tags": ["security", "sast", f.language]
                }
            }

        uri = Path(f.file).as_posix()
        results.append({
            "ruleId": rule_id,
            "level": SEVERITY_LEVEL.get(f.severity, "warning"),
            "message": {"text": f"{f.title}: {f.description}"},
            "locations": [{
                "physicalLocation": {
                    "artifactLocation": {"uri": uri},
                    "region": {"startLine": max(1, int(f.line or 1))}
                }
            }],
            "properties": {
                "severity": f.severity,
                "language": f.language,
                "reference": f.reference,
                "recommendation": f.recommendation
            }
        })

    sarif = {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": __version__,
        "runs": [{
            "tool": {
                "driver": {
                    "name": "SumScan SastBot",
                    "version": __version__,
                    "informationUri": "https://github.com/",
                    "rules": list(rules.values())
                }
            },
            "automationDetails": {"description": {"text": f"SumScan analysis of {target}"}},
            "results": results
        }]
    }
    Path(path).write_text(json.dumps(sarif, indent=2), encoding="utf-8")

def export_html(path, payload):
    gate = payload.get("quality_gate") or {}
    findings = payload.get("findings") or []

    counts = {"Critical":0,"High":0,"Medium":0,"Low":0}
    for f in findings:
        counts[f.get("severity","Low")] = counts.get(f.get("severity","Low"), 0) + 1

    rows = []
    for index, f in enumerate(findings):
        ref = f.get("reference","")
        url = reference_url(ref)
        ref_html = (
            f'<a href="{html.escape(url)}" target="_blank">{html.escape(ref)}</a>'
            if url else html.escape(ref)
        )
        rows.append(f"""
        <tr data-severity="{html.escape(f.get('severity',''))}">
          <td>{index+1}</td>
          <td><span class="sev {html.escape(f.get('severity','').lower())}">{html.escape(f.get('severity',''))}</span></td>
          <td>{html.escape(f.get('language',''))}</td>
          <td>{html.escape(f.get('title',''))}</td>
          <td><code>{html.escape(f.get('file',''))}:{f.get('line',1)}</code></td>
          <td>{ref_html}</td>
          <td><details><summary>View</summary><pre>{html.escape(f.get('snippet',''))}</pre>
          <p>{html.escape(f.get('description',''))}</p>
          <strong>Fix:</strong> {html.escape(f.get('recommendation',''))}</details></td>
        </tr>
        """)

    doc = f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>SumScan SastBot Report</title>
<style>
:root {{ color-scheme: dark; }}
body {{ margin:0; font-family:Inter,Segoe UI,Arial,sans-serif; background:#07111f; color:#e7eef8; }}
header {{ padding:28px 34px; background:linear-gradient(120deg,#0c1a2e,#151741); border-bottom:1px solid #29405f; }}
h1 {{ margin:0 0 6px; }}
.meta {{ color:#91a6c0; }}
.grid {{ display:grid; grid-template-columns:repeat(6,minmax(120px,1fr)); gap:12px; padding:20px 34px; }}
.card {{ background:#0d1b2f; border:1px solid #28415f; border-radius:12px; padding:16px; }}
.value {{ font-size:28px; font-weight:700; }}
.filters {{ padding:0 34px 16px; display:flex; gap:8px; flex-wrap:wrap; }}
button {{ background:#132945; color:#e7eef8; border:1px solid #315174; border-radius:8px; padding:8px 12px; cursor:pointer; }}
table {{ width:calc(100% - 68px); margin:0 34px 34px; border-collapse:collapse; background:#091626; }}
th,td {{ padding:10px; border-bottom:1px solid #20334c; text-align:left; vertical-align:top; }}
th {{ position:sticky; top:0; background:#102139; }}
code,pre {{ white-space:pre-wrap; word-break:break-word; }}
a {{ color:#7dd3fc; }}
.sev {{ font-weight:700; }}
.critical {{ color:#ff6682; }} .high {{ color:#fb923c; }} .medium {{ color:#facc15; }} .low {{ color:#22c55e; }}
.hidden {{ display:none; }}
</style>
<script>
function filterSeverity(sev) {{
  document.querySelectorAll('tbody tr').forEach(row => {{
    row.classList.toggle('hidden', sev !== 'All' && row.dataset.severity !== sev);
  }});
}}
</script>
</head>
<body>
<header>
  <h1>SumScan SastBot</h1>
  <div class="meta">Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.</div>
  <div class="meta">{html.escape(payload.get("target",""))}</div>
</header>

<section class="grid">
  <div class="card"><div>Quality Gate</div><div class="value">{html.escape(str(gate.get("status","N/A")))}</div></div>
  <div class="card"><div>Security Score</div><div class="value">{html.escape(str(gate.get("score","—")))}</div></div>
  <div class="card"><div>Critical</div><div class="value critical">{counts["Critical"]}</div></div>
  <div class="card"><div>High</div><div class="value high">{counts["High"]}</div></div>
  <div class="card"><div>Medium</div><div class="value medium">{counts["Medium"]}</div></div>
  <div class="card"><div>Low</div><div class="value low">{counts["Low"]}</div></div>
</section>

<div class="filters">
  <button onclick="filterSeverity('All')">All</button>
  <button onclick="filterSeverity('Critical')">Critical</button>
  <button onclick="filterSeverity('High')">High</button>
  <button onclick="filterSeverity('Medium')">Medium</button>
  <button onclick="filterSeverity('Low')">Low</button>
</div>

<table>
<thead><tr><th>#</th><th>Severity</th><th>Language</th><th>Finding</th><th>Location</th><th>Reference</th><th>Details</th></tr></thead>
<tbody>{''.join(rows)}</tbody>
</table>
</body></html>"""
    Path(path).write_text(doc, encoding="utf-8")



def export_pdf(path, target, findings, metrics, gate):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
    styles=getSampleStyleSheet()
    doc=SimpleDocTemplate(str(path),pagesize=landscape(A4),rightMargin=28,leftMargin=28,topMargin=28,bottomMargin=28)
    title=ParagraphStyle("title",parent=styles["Title"],fontSize=22,textColor=colors.HexColor("#173A75"))
    small=ParagraphStyle("small",parent=styles["BodyText"],fontSize=8,leading=10)
    body=styles["BodyText"]
    story=[
        Paragraph(f"SumScan SastBot {__version__}",title),
        Paragraph("Application Security & DevSecOps Analysis Report",styles["Heading2"]),
        Spacer(1,8),
        Paragraph(f"<b>Target:</b> {target}",body),
        Paragraph(f"<b>Quality Gate:</b> {getattr(gate,'status','N/A')} &nbsp;&nbsp; <b>Security Score:</b> {getattr(gate,'score','N/A')}/100",body),
        Paragraph(f"<b>Total Findings:</b> {len(findings)}",body),
        Spacer(1,12),
    ]
    counts={s:sum(1 for f in findings if f.severity==s) for s in ("Critical","High","Medium","Low")}
    summary=[["Critical","High","Medium","Low","Technical Debt"] ,
             [counts["Critical"],counts["High"],counts["Medium"],counts["Low"],f"{getattr(gate,'technical_debt_minutes',0)} min"]]
    st=Table(summary,colWidths=[95,95,95,95,130])
    st.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#173A75")),("TEXTCOLOR",(0,0),(-1,0),colors.white),
        ("GRID",(0,0),(-1,-1),.4,colors.HexColor("#98A8BC")),("ALIGN",(0,0),(-1,-1),"CENTER"),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("PADDING",(0,0),(-1,-1),7),
    ]))
    story += [st,Spacer(1,14),Paragraph("Findings",styles["Heading2"])]
    rows=[["Severity","Rule","Finding","Location","CWE / Ref","Recommendation"]]
    for f in findings:
        rows.append([
            f.severity,
            f.rule_id,
            Paragraph(f.title,small),
            Paragraph(f"{f.file}:{f.line}",small),
            f.reference,
            Paragraph(f.recommendation,small),
        ])
    table=Table(rows,colWidths=[55,95,150,220,85,230],repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#102139")),("TEXTCOLOR",(0,0),(-1,0),colors.white),
        ("GRID",(0,0),(-1,-1),.3,colors.HexColor("#AAB7C8")),("VALIGN",(0,0),(-1,-1),"TOP"),
        ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),8),("PADDING",(0,0),(-1,-1),5),
    ]))
    story.append(table)
    doc.build(story)
