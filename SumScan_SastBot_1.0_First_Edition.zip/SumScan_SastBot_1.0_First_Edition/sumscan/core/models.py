# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
#
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
#
# Intended for authorized defensive security, secure code review, software
# quality assurance, remediation, and Application Security (AppSec).
# See LICENSE.txt for full terms, limitations, and third-party notices.
# =============================================================================

from dataclasses import dataclass, asdict

@dataclass
class Finding:
    rule_id: str
    language: str
    title: str
    severity: str
    file: str
    line: int
    snippet: str
    description: str
    impact: str
    recommendation: str
    reference: str

    def to_dict(self):
        return asdict(self)
