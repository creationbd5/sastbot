# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
#
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
#
# Intended for authorized defensive security, secure code review, software
# quality assurance, remediation, and Application Security (AppSec).
# See LICENSE.txt for full terms, limitations, and third-party notices.
# =============================================================================

from .plugins import builtin_plugins
from .quality import evaluate
class AnalysisEngine:
    def __init__(self,plugins=None): self.plugins=plugins or builtin_plugins()
    def plugin_status(self):
        out=[]
        for p in self.plugins:
            ok,note=p.available(); out.append({'id':p.plugin_id,'name':p.display_name,'category':p.category,'available':ok,'note':note})
        return out
    def analyze(self,target,enabled=None,progress=None):
        enabled=set(enabled or [p.plugin_id for p in self.plugins]); findings=[]; metrics={}; warnings=[]; selected=[p for p in self.plugins if p.plugin_id in enabled]
        for i,p in enumerate(selected,1):
            ok,note=p.available()
            if progress: progress(int((i-1)/max(1,len(selected))*100),'Starting '+p.display_name)
            if not ok: warnings.append(p.display_name+': '+note); continue
            if not p.supports(target): continue
            r=p.analyze(target); findings.extend(r.findings); metrics.update(r.metrics); warnings.extend(r.warnings)
            if progress: progress(int(i/max(1,len(selected))*100),'Completed '+p.display_name)
        unique=[]; seen=set()
        for f in findings:
            key=(f.file,f.line,f.title,f.severity)
            if key in seen: continue
            seen.add(key); unique.append(f)
        return {'findings':unique,'metrics':metrics,'warnings':warnings,'quality_gate':evaluate(unique)}
