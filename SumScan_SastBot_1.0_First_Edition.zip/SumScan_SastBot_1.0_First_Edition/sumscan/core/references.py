# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
#
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
#
# Intended for authorized defensive security, secure code review, software
# quality assurance, remediation, and Application Security (AppSec).
# See LICENSE.txt for full terms, limitations, and third-party notices.
# =============================================================================

import re
from urllib.parse import quote_plus

CWE_RE = re.compile(r"\bCWE-(\d+)\b", re.IGNORECASE)

def cwe_id(reference):
    match = CWE_RE.search(reference or "")
    return match.group(1) if match else None

def reference_url(reference):
    cwe = cwe_id(reference)
    if cwe:
        return f"https://cwe.mitre.org/data/definitions/{cwe}.html"
    if reference:
        return "https://www.google.com/search?q=" + quote_plus(reference)
    return ""
