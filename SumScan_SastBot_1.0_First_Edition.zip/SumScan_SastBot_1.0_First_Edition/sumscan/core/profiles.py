# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
#
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
#
# Intended for authorized defensive security, secure code review, software
# quality assurance, remediation, and Application Security (AppSec).
# See LICENSE.txt for full terms, limitations, and third-party notices.
# =============================================================================

from dataclasses import dataclass

@dataclass(frozen=True)
class SecurityProfile:
    profile_id: str
    title: str
    description: str
    focus_cwes: tuple[str, ...]
    review_areas: tuple[str, ...]

FINANCIAL_WEB_API = SecurityProfile(
    "financial-web-api",
    "Banking / E-commerce / Financial Web & API",
    "Risk-prioritized secure-code review profile for applications that process "
    "accounts, payments, financial records, sessions, identities, and sensitive data.",
    (
        "CWE-79", "CWE-20", "CWE-89", "CWE-200", "CWE-352", "CWE-78",
        "CWE-22", "CWE-287", "CWE-434", "CWE-94", "CWE-522", "CWE-611",
        "CWE-798", "CWE-502", "CWE-269", "CWE-306", "CWE-862",
    ),
    (
        "Identity and account lifecycle",
        "Authentication and credential handling",
        "Authorization and object-level access control",
        "Session and cookie security",
        "Input validation and injection sinks",
        "Sensitive data exposure",
        "Cryptography and transport assumptions",
        "Error handling and stack-trace leakage",
        "Business-logic integrity and workflow controls",
        "File upload and parser safety",
        "Audit logging integrity",
        "API request/response trust boundaries",
    ),
)

PROFILES = {FINANCIAL_WEB_API.profile_id: FINANCIAL_WEB_API}
