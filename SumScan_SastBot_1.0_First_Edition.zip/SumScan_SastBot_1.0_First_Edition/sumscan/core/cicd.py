# =============================================================================
# SumScan SastBot 1.0
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
# =============================================================================

from pathlib import Path

GITHUB_WORKFLOW = """name: SumScan SastBot
on:
  push:
  pull_request:

permissions:
  contents: read
  security-events: write

jobs:
  sumscan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'
      - name: Install SumScan dependencies
        run: python -m pip install -r requirements.txt
      - name: Run repository security analysis
        run: |
          echo "Run SumScan SastBot CLI/SARIF integration here when deployed in your CI environment."
      - name: Security gate
        run: echo "Configure your organization-approved SumScan CLI invocation and SARIF upload."
"""

GITLAB_TEMPLATE = """stages:
  - security

sumscan_sast:
  stage: security
  image: python:3.12
  script:
    - python -m pip install -r requirements.txt
    - echo "Configure the organization-approved SumScan SastBot CLI/SARIF command here."
  artifacts:
    when: always
    paths:
      - reports/
"""

def save_github_template(folder):
    path=Path(folder)/"sumscan-github-actions.yml"
    path.write_text(GITHUB_WORKFLOW,encoding="utf-8")
    return path

def save_gitlab_template(folder):
    path=Path(folder)/"sumscan-gitlab-ci.yml"
    path.write_text(GITLAB_TEMPLATE,encoding="utf-8")
    return path
