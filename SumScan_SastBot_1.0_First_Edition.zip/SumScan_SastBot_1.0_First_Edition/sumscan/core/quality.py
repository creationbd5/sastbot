# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
#
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
#
# Intended for authorized defensive security, secure code review, software
# quality assurance, remediation, and Application Security (AppSec).
# See LICENSE.txt for full terms, limitations, and third-party notices.
# =============================================================================

from dataclasses import dataclass
@dataclass
class QualityGate:
    status:str; score:int; reason:str; technical_debt_minutes:int
FIX={'Critical':90,'High':60,'Medium':30,'Low':10}
def evaluate(findings):
    c={'Critical':0,'High':0,'Medium':0,'Low':0}; debt=0
    for f in findings: c[f.severity]=c.get(f.severity,0)+1; debt+=FIX.get(f.severity,15)
    score=max(0,100-(c['Critical']*25+c['High']*12+c['Medium']*4+c['Low']))
    if c['Critical']: return QualityGate('FAILED',score,'Critical findings require review.',debt)
    if c['High']>=3: return QualityGate('FAILED',score,'High severity threshold exceeded.',debt)
    if score<70: return QualityGate('WARNING',score,'Security score below recommended threshold.',debt)
    return QualityGate('PASSED',score,'No blocking quality-gate condition detected.',debt)
