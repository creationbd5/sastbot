# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
#
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
#
# Intended for authorized defensive security, secure code review, software
# quality assurance, remediation, and Application Security (AppSec).
# See LICENSE.txt for full terms, limitations, and third-party notices.
# =============================================================================

import json, shutil, subprocess, tempfile
from pathlib import Path
from sumscan.core.plugin_api import AnalyzerPlugin, AnalyzerResult
from sumscan.core.models import Finding

SM={'ERROR':'High','WARNING':'Medium','INFO':'Low','CRITICAL':'Critical','HIGH':'High','MEDIUM':'Medium','LOW':'Low','UNKNOWN':'Low'}
class CLI(AnalyzerPlugin):
    executable=''
    def available(self):
        p=shutil.which(self.executable); return bool(p), p or 'Not installed'
    def supports(self,target): return Path(target).exists()
    def run(self,args,timeout=300): return subprocess.run(args,capture_output=True,text=True,timeout=timeout,check=False)

class SemgrepPlugin(CLI):
    plugin_id='external.semgrep'; display_name='Semgrep'; category='Multi-language SAST'; executable='semgrep'
    def analyze(self,target):
        if not self.available()[0]: return AnalyzerResult(self.display_name,warnings=['Semgrep not installed'])
        p=self.run(['semgrep','scan','--config','auto','--json','--quiet',target])
        try: data=json.loads(p.stdout or '{}')
        except Exception: return AnalyzerResult(self.display_name,warnings=['Unable to parse Semgrep JSON'])
        out=[]
        for x in data.get('results',[]):
            e=x.get('extra',{}); st=x.get('start',{}); sev=SM.get(str(e.get('severity','WARNING')).upper(),'Medium')
            out.append(Finding('SEMGREP:'+x.get('check_id','rule'),'Multi',e.get('message','Semgrep finding'),sev,x.get('path',''),int(st.get('line',1)),'',e.get('message','Semgrep finding'),'Validate reachable impact.','Apply the rule guidance and remediate the unsafe pattern.','Semgrep'))
        return AnalyzerResult(self.display_name,out,{'semgrep_findings':len(out)},[])

class BanditPlugin(CLI):
    plugin_id='external.bandit'; display_name='Bandit'; category='Python SAST'; executable='bandit'
    def analyze(self,target):
        if not self.available()[0]: return AnalyzerResult(self.display_name,warnings=['Bandit not installed'])
        args=['bandit','-r',target,'-f','json','-q'] if Path(target).is_dir() else ['bandit',target,'-f','json','-q']; p=self.run(args)
        try: data=json.loads(p.stdout or '{}')
        except Exception: return AnalyzerResult(self.display_name,warnings=['Unable to parse Bandit JSON'])
        out=[]
        for x in data.get('results',[]):
            out.append(Finding('BANDIT:'+x.get('test_id',''),'Python',x.get('test_name','Bandit finding'),SM.get(str(x.get('issue_severity','MEDIUM')).upper(),'Medium'),x.get('filename',''),int(x.get('line_number',1)),x.get('code','').strip(),x.get('issue_text',''),'Validate exploitability.','Apply the secure alternative recommended by Bandit.',x.get('more_info','Bandit')))
        return AnalyzerResult(self.display_name,out,{'bandit_findings':len(out)},[])

class TrivyPlugin(CLI):
    plugin_id='external.trivy'; display_name='Trivy Filesystem'; category='SCA / Secrets'; executable='trivy'
    def analyze(self,target):
        if not self.available()[0]: return AnalyzerResult(self.display_name,warnings=['Trivy not installed'])
        p=self.run(['trivy','fs','--format','json','--quiet',target])
        try: data=json.loads(p.stdout or '{}')
        except Exception: return AnalyzerResult(self.display_name,warnings=['Unable to parse Trivy JSON'])
        out=[]
        for r in data.get('Results',[]) or []:
            tgt=r.get('Target',target)
            for v in r.get('Vulnerabilities',[]) or []:
                out.append(Finding('TRIVY:'+v.get('VulnerabilityID',''),'Dependency',v.get('Title') or v.get('PkgName','Dependency vulnerability'),SM.get(str(v.get('Severity','UNKNOWN')).upper(),'Low'),tgt,1,v.get('PkgName',''),v.get('Description','Known vulnerable dependency.'),'Known vulnerable dependency may expose the application.',f"Upgrade {v.get('PkgName','dependency')} to {v.get('FixedVersion') or 'a fixed version'}.",v.get('PrimaryURL') or 'Trivy'))
            for s in r.get('Secrets',[]) or []:
                out.append(Finding('TRIVY-SECRET:'+s.get('RuleID',''),'Secret',s.get('Title','Detected Secret'),'Critical',tgt,int(s.get('StartLine',1)),s.get('Match',''),'Trivy detected a possible credential.','Exposed credentials may enable unauthorized access.','Validate, remove and rotate the credential.','Trivy Secret Scanner'))
        return AnalyzerResult(self.display_name,out,{'trivy_findings':len(out)},[])

class GitleaksPlugin(CLI):
    plugin_id='external.gitleaks'; display_name='Gitleaks'; category='Secrets'; executable='gitleaks'
    def analyze(self,target):
        if not self.available()[0]: return AnalyzerResult(self.display_name,warnings=['Gitleaks not installed'])
        with tempfile.NamedTemporaryFile(suffix='.json',delete=False) as t: report=t.name
        try:
            self.run(['gitleaks','dir',target,'--report-format','json','--report-path',report,'--no-banner'],180)
            try: data=json.loads(Path(report).read_text(encoding='utf-8') or '[]')
            except Exception: data=[]
        finally: Path(report).unlink(missing_ok=True)
        out=[]
        for x in data if isinstance(data,list) else []:
            out.append(Finding('GITLEAKS:'+str(x.get('RuleID','secret')),'Secret',x.get('Description','Potential Secret'),'Critical',x.get('File',''),int(x.get('StartLine',1)),x.get('Match',''),'Gitleaks detected a potential credential.','Exposed secrets can enable unauthorized access.','Validate, remove from source control, and rotate the credential.','Gitleaks'))
        return AnalyzerResult(self.display_name,out,{'gitleaks_findings':len(out)},[])



class TreeSitterPlugin(AnalyzerPlugin):
    """
    Optional multi-language structural parsing backend.

    Uses tree-sitter-language-pack when installed. The wrapper parses supported
    source files and reports structural metrics and syntax-error hotspots.
    It intentionally does not label ordinary syntax errors as exploitable
    security vulnerabilities.
    """
    plugin_id = "external.treesitter"
    display_name = "Tree-sitter Language Pack"
    category = "Multi-language AST"

    EXTENSION_LANGUAGE = {
        ".py": "python",
        ".js": "javascript",
        ".jsx": "javascript",
        ".ts": "typescript",
        ".tsx": "tsx",
        ".php": "php",
        ".java": "java",
        ".c": "c",
        ".h": "c",
        ".cc": "cpp",
        ".cpp": "cpp",
        ".cxx": "cpp",
        ".hpp": "cpp",
        ".cs": "c_sharp",
        ".go": "go",
        ".rs": "rust",
        ".rb": "ruby",
        ".kt": "kotlin",
        ".swift": "swift",
    }

    def available(self):
        try:
            import tree_sitter_language_pack  # noqa: F401
            return True, "tree-sitter-language-pack detected"
        except Exception:
            return False, "Install optional tree-sitter-language-pack"

    def supports(self, target):
        path = Path(target)
        if path.is_file():
            return path.suffix.lower() in self.EXTENSION_LANGUAGE
        if not path.exists():
            return False
        return any(
            p.is_file() and p.suffix.lower() in self.EXTENSION_LANGUAGE
            for p in path.rglob("*")
        )

    def analyze(self, target):
        ok, note = self.available()
        if not ok:
            return AnalyzerResult(self.display_name, warnings=[note])

        from tree_sitter_language_pack import get_parser

        path = Path(target)
        files = [path] if path.is_file() else [
            p for p in path.rglob("*")
            if p.is_file()
            and p.suffix.lower() in self.EXTENSION_LANGUAGE
            and not any(x in p.parts for x in {".git","node_modules",".venv","venv","vendor","dist","build"})
        ]

        parsed = 0
        syntax_error_files = 0
        node_count = 0
        languages = set()
        findings = []
        warnings = []

        for file in files:
            language = self.EXTENSION_LANGUAGE.get(file.suffix.lower())
            if not language:
                continue
            try:
                parser = get_parser(language)
                source = file.read_bytes()
                tree = parser.parse(source)
                root = tree.root_node
                parsed += 1
                languages.add(language)

                stack = [root]
                local_nodes = 0
                while stack:
                    node = stack.pop()
                    local_nodes += 1
                    stack.extend(node.children)
                node_count += local_nodes

                if root.has_error:
                    syntax_error_files += 1
                    findings.append(Finding(
                        "TREESITTER:PARSE-ERROR",
                        language,
                        "Syntax / Parse Error Hotspot",
                        "Low",
                        str(file),
                        1,
                        "",
                        "Tree-sitter found one or more parse errors in this source file.",
                        "Parsing errors can reduce static-analysis coverage and hide security-relevant code paths.",
                        "Fix syntax errors or confirm the selected parser matches the source language.",
                        "Tree-sitter"
                    ))
            except Exception as exc:
                warnings.append(f"{file.name}: {exc}")

        return AnalyzerResult(
            self.display_name,
            findings=findings,
            metrics={
                "treesitter_files_parsed": parsed,
                "treesitter_syntax_error_files": syntax_error_files,
                "treesitter_node_count": node_count,
                "treesitter_languages": sorted(languages),
            },
            warnings=warnings,
        )
