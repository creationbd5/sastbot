# =============================================================================
# SumScan SastBot 1.0
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
# =============================================================================

import re
from collections import Counter
from pathlib import Path
from sumscan.core.plugin_api import AnalyzerPlugin, AnalyzerResult
from sumscan.core.models import Finding

LANG_MAP={
    ".py":"Python",".js":"JavaScript",".jsx":"JavaScript",".ts":"TypeScript",".tsx":"TypeScript",
    ".php":"PHP",".java":"Java",".cs":"C#",".go":"Go",".rb":"Ruby",".c":"C",".h":"C/C++",
    ".cc":"C++",".cpp":"C++",".cxx":"C++",".hpp":"C++",".kt":"Kotlin",".kts":"Kotlin",
    ".rs":"Rust",".swift":"Swift",".scala":"Scala",".vue":"Vue",".svelte":"Svelte"
}
MANIFESTS={
    "requirements.txt":"Python","pyproject.toml":"Python","Pipfile":"Python",
    "package.json":"Node.js","package-lock.json":"Node.js","yarn.lock":"Node.js","pnpm-lock.yaml":"Node.js",
    "pom.xml":"Java","build.gradle":"Java/Gradle","build.gradle.kts":"Kotlin/Gradle",
    "go.mod":"Go","composer.json":"PHP",".csproj":"C#","Cargo.toml":"Rust","Gemfile":"Ruby"
}
IGNORE={".git","node_modules",".venv","venv","vendor","dist","build","__pycache__"}

class DevSecOpsProjectAnalyzer(AnalyzerPlugin):
    plugin_id="builtin.devsecops"
    display_name="DevSecOps Project Analyzer"
    category="Code Quality / CI-CD"

    def available(self):
        return True,"Built-in"

    def supports(self,target):
        return Path(target).exists()

    def analyze(self,target):
        root=Path(target)
        if root.is_file():
            root=root.parent
        languages=Counter()
        manifests=[]
        ci=[]
        containers=[]
        findings=[]
        code_files=0

        for p in root.rglob("*"):
            if not p.is_file() or any(part in IGNORE for part in p.parts):
                continue
            ext=p.suffix.lower()
            if ext in LANG_MAP:
                languages[LANG_MAP[ext]]+=1
                code_files+=1
            if p.name in MANIFESTS or ext in {".csproj"}:
                manifests.append(str(p))
            rel=p.relative_to(root).as_posix()
            if rel.startswith(".github/workflows/") and ext in {".yml",".yaml"}:
                ci.append(str(p)); self._review_ci(p,findings)
            elif p.name in {".gitlab-ci.yml","Jenkinsfile","azure-pipelines.yml"}:
                ci.append(str(p))
            if p.name.startswith("Dockerfile"):
                containers.append(str(p)); self._review_docker(p,findings)
            if ext in {".yml",".yaml"}:
                self._review_k8s(p,findings)
            if p.name.lower() in {".env",".env.production",".env.prod"}:
                self._review_env(p,findings)

        return AnalyzerResult(
            self.display_name,
            findings=findings,
            metrics={
                "code_files":code_files,
                "language_inventory":dict(languages.most_common()),
                "manifests":manifests[:100],
                "manifest_count":len(manifests),
                "ci_files":ci[:100],
                "ci_file_count":len(ci),
                "container_files":containers[:50],
                "container_file_count":len(containers),
            },
            warnings=[]
        )

    def _lines(self,p):
        try:return p.read_text(encoding="utf-8",errors="replace").splitlines()
        except Exception:return []

    def _add(self,out,p,line,rule,title,severity,snippet,description,impact,fix,ref):
        out.append(Finding(rule,"DevSecOps",title,severity,str(p),line,snippet,description,impact,fix,ref))

    def _review_docker(self,p,out):
        for i,line in enumerate(self._lines(p),1):
            s=line.strip()
            if re.search(r"(?i)^FROM\s+\S+:latest\b",s):
                self._add(out,p,i,"DEV-DOCKER-001","Unpinned Docker Base Tag","Medium",s,
                    "Docker image uses the mutable latest tag.",
                    "Mutable base images reduce build reproducibility and can introduce unreviewed changes.",
                    "Pin an explicit image version or immutable digest and update it through a controlled dependency process.","CWE-1104")
            if re.search(r"(?i)^USER\s+root\b",s):
                self._add(out,p,i,"DEV-DOCKER-002","Container Runs as Root","Medium",s,
                    "Dockerfile explicitly switches to the root user.",
                    "A compromised process can have broader privileges inside the container.",
                    "Use a dedicated non-root runtime user when the application does not require root privileges.","CWE-250")

    def _review_ci(self,p,out):
        for i,line in enumerate(self._lines(p),1):
            s=line.strip()
            if re.search(r"uses:\s*[^@\s]+@(master|main|latest)\b",s,re.I):
                self._add(out,p,i,"DEV-CI-001","Mutable CI Action Reference","Medium",s,
                    "CI workflow references an action using a mutable branch/tag.",
                    "Upstream changes may enter the build without an explicit review.",
                    "Pin third-party actions to a reviewed immutable commit SHA and update deliberately.","CWE-829")
            if re.search(r"(?i)(password|token|secret)\s*:\s*[\"']?[A-Za-z0-9_\-]{8,}",s) and "${{" not in s:
                self._add(out,p,i,"DEV-CI-002","Potential CI Secret in Workflow","Critical",s,
                    "A secret-like value may be embedded directly in CI configuration.",
                    "Credentials in workflow files can leak through source control.",
                    "Store credentials in the CI secret store and rotate any exposed secret.","CWE-798")

    def _review_k8s(self,p,out):
        for i,line in enumerate(self._lines(p),1):
            s=line.strip()
            if re.search(r"(?i)^privileged:\s*true\b",s):
                self._add(out,p,i,"DEV-K8S-001","Privileged Container","High",s,
                    "Kubernetes container is configured as privileged.",
                    "Privileged containers can significantly weaken workload isolation.",
                    "Remove privileged mode and grant only the capabilities/resources the workload actually needs.","CWE-250")
            if re.search(r"(?i)^allowPrivilegeEscalation:\s*true\b",s):
                self._add(out,p,i,"DEV-K8S-002","Privilege Escalation Allowed","High",s,
                    "Kubernetes security context allows privilege escalation.",
                    "A compromised workload may gain additional process privileges.",
                    "Set allowPrivilegeEscalation to false unless a documented requirement exists.","CWE-250")

    def _review_env(self,p,out):
        for i,line in enumerate(self._lines(p),1):
            if re.search(r"(?i)^\s*(PASSWORD|SECRET|API_KEY|ACCESS_TOKEN|AUTH_TOKEN)\s*=\s*\S{6,}",line):
                self._add(out,p,i,"DEV-ENV-001","Secret in Environment File","Critical",line.strip(),
                    "A secret-like value exists in an environment file inside the scanned project.",
                    "If committed or distributed, credentials can be exposed.",
                    "Keep real .env secrets out of version control, use templates for names only, and rotate exposed values.","CWE-798")
