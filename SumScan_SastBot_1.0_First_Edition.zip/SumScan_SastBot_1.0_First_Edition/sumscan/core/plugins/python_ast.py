# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
#
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
#
# Intended for authorized defensive security, secure code review, software
# quality assurance, remediation, and Application Security (AppSec).
# See LICENSE.txt for full terms, limitations, and third-party notices.
# =============================================================================

import ast
from pathlib import Path
from sumscan.core.plugin_api import AnalyzerPlugin, AnalyzerResult
from sumscan.core.models import Finding

class PythonASTAnalyzer(AnalyzerPlugin):
    plugin_id='builtin.python_ast'; display_name='Python AST Analyzer'; category='AST'
    def available(self): return True, 'Python stdlib ast'
    def supports(self,target):
        p=Path(target)
        return p.suffix.lower()=='.py' if p.is_file() else (p.exists() and any(p.rglob('*.py')))
    def analyze(self,target):
        p=Path(target); files=[p] if p.is_file() else list(p.rglob('*.py'))
        findings=[]; functions=classes=branches=loc=0
        for file in files:
            if any(x in file.parts for x in {'.git','.venv','venv','__pycache__','node_modules'}): continue
            try:
                src=file.read_text(encoding='utf-8',errors='replace'); tree=ast.parse(src,filename=str(file)); lines=src.splitlines(); loc+=len(lines)
            except Exception: continue
            for node in ast.walk(tree):
                if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                    functions+=1
                    c=1+sum(isinstance(n,(ast.If,ast.For,ast.AsyncFor,ast.While,ast.Try,ast.BoolOp,ast.IfExp,ast.Match)) for n in ast.walk(node)); branches+=c
                    if c>=12: findings.append(self.f(file,node.lineno,'PY-AST-CPLX-001','High Cyclomatic Complexity','Medium',lines,f"Function {node.name} has estimated complexity {c}.",'Complex code is harder to review and test.','Split complex logic into smaller functions.','Maintainability'))
                elif isinstance(node,ast.ClassDef): classes+=1
                elif isinstance(node,ast.Call):
                    name=self.call_name(node.func)
                    if name in {'eval','exec'}: findings.append(self.f(file,node.lineno,'PY-AST-DYN-001','Dynamic Code Execution','High',lines,f'AST confirmed {name}().','Untrusted data can become code execution.','Replace dynamic execution with explicit parsing.','CWE-95'))
                    if name in {'subprocess.run','subprocess.Popen','subprocess.call'} and any(k.arg=='shell' and isinstance(k.value,ast.Constant) and k.value.value is True for k in node.keywords):
                        findings.append(self.f(file,node.lineno,'PY-AST-CMD-001','Shell Execution Enabled','High',lines,'AST confirmed shell=True.','Untrusted input can become command injection.','Avoid shell=True and pass argument arrays.','CWE-78'))
                elif isinstance(node,ast.Assign) and isinstance(node.value,ast.Constant) and isinstance(node.value.value,str) and len(node.value.value)>=6:
                    for t in node.targets:
                        if isinstance(t,ast.Name) and any(k in t.id.lower() for k in ('password','secret','api_key','apikey','token')):
                            findings.append(self.f(file,node.lineno,'PY-AST-SECRET-001','Hardcoded Secret (AST)','Critical',lines,'AST identified a secret-like string assignment.','Credentials in source code can leak.','Move secrets to environment configuration and rotate exposed values.','CWE-798'))
        avg=round(branches/functions,2) if functions else 0
        return AnalyzerResult(self.display_name,findings,{'python_files':len(files),'lines_of_code':loc,'functions':functions,'classes':classes,'avg_complexity':avg},[])
    def call_name(self,node):
        if isinstance(node,ast.Name): return node.id
        if isinstance(node,ast.Attribute):
            parts=[]
            while isinstance(node,ast.Attribute): parts.append(node.attr); node=node.value
            if isinstance(node,ast.Name): parts.append(node.id)
            return '.'.join(reversed(parts))
        return ''
    def f(self,file,line,rule,title,severity,lines,description,impact,rec,ref):
        snippet=lines[line-1].strip() if 0<line<=len(lines) else ''
        return Finding(rule,'Python',title,severity,str(file),line,snippet,description,impact,rec,ref)
