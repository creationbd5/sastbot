# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
#
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
#
# Intended for authorized defensive security, secure code review, software
# quality assurance, remediation, and Application Security (AppSec).
# See LICENSE.txt for full terms, limitations, and third-party notices.
# =============================================================================

from sumscan.core.plugin_api import AnalyzerPlugin, AnalyzerResult
from sumscan.core.scanner import discover_files, scan_files_parallel

class RegexAnalyzer(AnalyzerPlugin):
    plugin_id = "builtin.regex"
    display_name = "Built-in Pattern Engine"
    category = "SAST"

    def available(self):
        return True, "Built-in parallel engine"

    def supports(self, target):
        return bool(discover_files(target))

    def analyze(self, target):
        files = discover_files(target)
        findings = scan_files_parallel(files)
        return AnalyzerResult(
            analyzer=self.display_name,
            findings=findings,
            metrics={"files_scanned": len(files), "pattern_findings": len(findings)}
        )
