# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
#
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
#
# Intended for authorized defensive security, secure code review, software
# quality assurance, remediation, and Application Security (AppSec).
# See LICENSE.txt for full terms, limitations, and third-party notices.
# =============================================================================

__version__ = "1.0.0"
PRODUCT_NAME = "SumScan SastBot"
