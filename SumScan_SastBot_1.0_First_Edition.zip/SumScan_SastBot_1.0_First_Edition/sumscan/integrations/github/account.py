import json
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass

@dataclass
class GitHubAccount:
    connected: bool
    username: str = ""
    message: str = ""

def gh_path():
    return shutil.which("gh") or ""

def _flags():
    return getattr(subprocess, "CREATE_NO_WINDOW", 0)

def account_status():
    path=gh_path()
    if not path:
        return GitHubAccount(False,message="GitHub CLI is not installed.")
    proc=subprocess.run([path,"auth","status","--hostname","github.com"],capture_output=True,text=True,timeout=30,creationflags=_flags())
    raw=((proc.stdout or "")+"\n"+(proc.stderr or "")).strip()
    if proc.returncode != 0:
        return GitHubAccount(False,message=raw or "GitHub account is not connected.")
    m=re.search(r"account\s+([A-Za-z0-9_.-]+)",raw,re.I)
    return GitHubAccount(True,username=m.group(1) if m else "",message=raw)

def begin_web_login():
    path=gh_path()
    if not path:
        raise RuntimeError("GitHub CLI is not installed. Install GitHub CLI first.")
    args=[path,"auth","login","--hostname","github.com","--web","--git-protocol","https"]
    subprocess.Popen(args,creationflags=getattr(subprocess,"CREATE_NEW_CONSOLE",0) if sys.platform.startswith("win") else 0)

def logout():
    path=gh_path()
    if not path: raise RuntimeError("GitHub CLI is not installed.")
    return subprocess.run([path,"auth","logout","--hostname","github.com"],capture_output=True,text=True,timeout=60)

def list_repositories(limit=100):
    path=gh_path()
    if not path: raise RuntimeError("GitHub CLI is not installed.")
    if not account_status().connected: raise RuntimeError("Connect a GitHub account first.")
    proc=subprocess.run(
        [path,"repo","list","--limit",str(limit),"--json","nameWithOwner,visibility,defaultBranchRef,url,isPrivate"],
        capture_output=True,text=True,timeout=90,creationflags=_flags()
    )
    if proc.returncode != 0:
        raise RuntimeError((proc.stderr or proc.stdout or "Could not list repositories.").strip())
    return json.loads(proc.stdout or "[]")
