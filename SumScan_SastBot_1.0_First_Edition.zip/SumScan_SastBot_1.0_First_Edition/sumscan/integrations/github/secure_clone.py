import re, shutil, subprocess, tempfile
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

@dataclass
class CloneResult:
    local_path: str
    repository: str
    branch: str
    commit: str
    transport: str

def validate_github_url(url: str) -> str:
    url=url.strip()
    parsed=urlparse(url)
    if parsed.scheme != "https" or parsed.netloc.lower() not in {"github.com","www.github.com"}:
        raise ValueError("Use an HTTPS github.com repository URL.")
    path=parsed.path.strip("/")
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+(?:\.git)?",path):
        raise ValueError("Repository URL must look like https://github.com/owner/repository")
    return "https://github.com/"+path.removesuffix(".git")+".git"

def _run(args,cwd=None):
    flags=getattr(subprocess,"CREATE_NO_WINDOW",0)
    return subprocess.run(args,cwd=cwd,capture_output=True,text=True,timeout=300,creationflags=flags)

def clone_repository(url: str, branch: str="main", use_existing_auth: bool=True) -> CloneResult:
    """Clone into a new local temp directory. No token is accepted or persisted by SumScan."""
    clean=validate_github_url(url)
    root=Path(tempfile.mkdtemp(prefix="sumscan_github_"))
    dest=root/"repository"
    branch=(branch or "main").strip()

    # For private repositories, existing Git/GitHub CLI credentials can be used.
    # SumScan deliberately does not request/store PATs.
    transport="git"
    cmd=["git","clone","--depth","1","--single-branch","--branch",branch,clean,str(dest)]
    proc=_run(cmd)
    if proc.returncode != 0 and use_existing_auth and shutil.which("gh"):
        # gh uses the user's existing authenticated credential store.
        proc=_run(["gh","repo","clone",clean.removesuffix(".git"),str(dest),"--","--depth","1","--branch",branch])
        transport="GitHub CLI"
    if proc.returncode != 0:
        shutil.rmtree(root,ignore_errors=True)
        msg=(proc.stderr or proc.stdout or "Clone failed").strip()
        raise RuntimeError(msg[-900:])

    commit=_run(["git","rev-parse","HEAD"],cwd=str(dest)).stdout.strip()
    actual_branch=_run(["git","branch","--show-current"],cwd=str(dest)).stdout.strip() or branch
    repo=clean.removeprefix("https://github.com/").removesuffix(".git")
    return CloneResult(str(dest),repo,actual_branch,commit,transport)

def cleanup_clone(local_path: str):
    p=Path(local_path)
    if p.name=="repository" and p.parent.name.startswith("sumscan_github_"):
        shutil.rmtree(p.parent,ignore_errors=True)
