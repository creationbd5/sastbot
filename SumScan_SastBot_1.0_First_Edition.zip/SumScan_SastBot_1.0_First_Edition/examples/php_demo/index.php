<?php
$password = "demo_password_123456";
$id = $_GET["id"];
$result = mysqli_query($db, "SELECT * FROM users WHERE id=" . $id);
$file = $_GET["page"];
include $file;
$cmd = $_GET["cmd"];
system($cmd);
?>
