const api_key = "demo_js_secret_123456";
const httpUrl = "http://example.com/api";
document.querySelector("#output").innerHTML = userHtml;
function run(code) { return eval(code); }
const options = { rejectUnauthorized: false };
