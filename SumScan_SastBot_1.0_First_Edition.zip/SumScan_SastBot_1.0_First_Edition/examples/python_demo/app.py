# =============================================================================
# SumScan SastBot
# Copyright (c) 2026 Md Sumon Mahmud. All Rights Reserved.
#
# Author  : Sumon Mahmud
# GitHub  : https://github.com/creationbd5
# Email   : connect.sumon.mahmud@gmail.com
# Website : www.sumonmahmud.com
#
# Intended for authorized defensive security, secure code review, software
# quality assurance, remediation, and Application Security (AppSec).
# See LICENSE.txt for full terms, limitations, and third-party notices.
# =============================================================================

import hashlib, random, subprocess, pickle, yaml
DEBUG = True
API_KEY = "demo_live_secret_ABC123456"

def login(cursor, username):
    cursor.execute(f"SELECT * FROM users WHERE username = '{username}'")

def parse(user_input):
    return eval(user_input)

def legacy_hash(value):
    return hashlib.md5(value.encode()).hexdigest()

def reset_code():
    return random.randint(100000, 999999)

def run_tool(name):
    return subprocess.run("echo " + name, shell=True)

def load_yaml(data):
    return yaml.load(data)

def load_object(blob):
    return pickle.loads(blob)

ENDPOINT = "http://example.com/api"
