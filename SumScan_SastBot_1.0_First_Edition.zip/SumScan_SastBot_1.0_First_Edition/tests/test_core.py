import tempfile
import unittest
from pathlib import Path

from sumscan.core.rules import RULES, RULE_PACK_VERSION
from sumscan.core.scanner import discover_files, scan_file, language_for

class CoreTests(unittest.TestCase):
    def test_rule_ids_are_unique(self):
        ids=[r.rule_id for r in RULES]
        self.assertEqual(len(ids),len(set(ids)))

    def test_rule_metadata(self):
        self.assertEqual(RULE_PACK_VERSION,"1.0.0")
        for rule in RULES:
            self.assertIn(rule.severity,{"Critical","High","Medium","Low"})
            self.assertTrue(rule.reference)
            self.assertTrue(rule.recommendation)

    def test_language_mapping(self):
        self.assertEqual(language_for(".cs"),"C#")
        self.assertEqual(language_for(".go"),"Go")
        self.assertEqual(language_for(".kt"),"Kotlin")

    def test_python_demo_detection(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/"app.py"
            p.write_text('API_KEY = "demo_secret_123456"\nvalue = eval(user_input)\n',encoding="utf-8")
            findings=scan_file(p)
            ids={f.rule_id for f in findings}
            self.assertIn("GEN-SEC-001",ids)
            self.assertIn("PY-EVAL-001",ids)

if __name__=="__main__":
    unittest.main()
